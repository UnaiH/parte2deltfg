package com.becdedalow.ms.resenas.domain.crud;

import com.becdedalow.ms.resenas.domain.entity.ResenaEntity;
import com.becdedalow.ms.resenas.domain.mapper.ResenaEntityMapper;
import com.becdedalow.ms.resenas.domain.model.ListaResenas;
import com.becdedalow.ms.resenas.domain.model.ListaResenasAux;
import com.becdedalow.ms.resenas.domain.model.Resena;
import com.becdedalow.ms.resenas.domain.repository.ResenaEntityRepository;
import java.util.ArrayList;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ResenaEntityServiceTest {
  @InjectMocks
  private ResenaEntityService resenaService;
  @Mock
  private ResenaEntityRepository repository;
  @Mock
  private ResenaEntityMapper mapper;

  @BeforeEach
  public void setUp() {
    System.out.println("Inicio de prueba");
    Mockito.when(mapper.fromApiDomain(Mockito.any(Resena.class))).thenReturn(new ResenaEntity());
    Mockito.when(mapper.fromApiDomain(Mockito.anyList())).thenReturn(new ArrayList<ResenaEntity>());
    Mockito.when(mapper.toApiDomain(Mockito.anyList())).thenReturn(new ArrayList<Resena>());
    Mockito.when(mapper.toApiDomain(Mockito.any(ResenaEntity.class))).thenReturn(new Resena());
  }

  @Test
  public void comprobarResenaTest() throws Exception {
    System.out.println("Inicio de prueba");
    Resena result = resenaService.findById("string", "string", "string");

    Assertions.assertNotNull(result);
  }

  @Test
  public void actualizarResenaTest() throws Exception {
    System.out.println("Inicio de prueba");
    Resena result = resenaService.update("string", "string", "string", "string");

    Assertions.assertNotNull(result);
  }

  @Test
  public void crearResenaTest() throws Exception {
    System.out.println("Inicio de prueba");
    Resena result = resenaService.create(
        Resena.builder()
            .titulo("string")
            .autor("string")
            .nombreUsuario("string")
            .texto("string")
            .build());

    Assertions.assertNotNull(result);
  }

  @Test
  public void eliminarResenaTest() throws Exception {
    System.out.println("Inicio de prueba");
    resenaService.remove("string", "string", "string");
  }

  @Test
  public void obtenerResenasTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.when(
        this.repository.obtenerResenas(
            Mockito.nullable(String.class), Mockito.nullable(String.class)))
        .thenReturn(new ListaResenas());

    ListaResenas response = resenaService.obtenerResenas("string", "string");

    Assertions.assertNotNull(response);
  }
}
