package com.becdedalow.ms.resenas.domain.entity;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

public class ResenaEntityIdTest {
    @Test
    public void pruebaId() {
        ResenaEntityId resId1 = null;
        assertNull(resId1);
        resId1 = new ResenaEntityId();
        assertNotNull(resId1);
        ResenaEntityId resId2 = new ResenaEntityId();
        assertNull(resId2.getAutor());
        assertNull(resId2.getTitulo());
        assertNull(resId2.getNombreUsuario());
        resId2.setAutor("Stephen King");
        resId2.setTitulo("It");
        resId2.setNombreUsuario("administrador");
        assertEquals(resId2.getAutor(), "Stephen King");
        assertEquals(resId2.getTitulo(), "It");
        assertEquals(resId2.getNombreUsuario(), "administrador");
    }

}
