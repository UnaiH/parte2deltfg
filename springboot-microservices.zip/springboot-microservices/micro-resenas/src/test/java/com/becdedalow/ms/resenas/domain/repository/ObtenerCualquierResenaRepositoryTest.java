package com.becdedalow.ms.resenas.domain.repository;

import com.becdedalow.ms.resenas.domain.model.ListaResenas;
import com.becdedalow.ms.resenas.domain.model.ResAux;
import com.becdedalow.ms.resenas.domain.model.Resena;

import java.util.Arrays;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ObtenerCualquierResenaRepositoryTest {
  @InjectMocks
  ObtenerCualquierResenaRepository repository;

  @Mock
  EntityManager entityManager;
  @Mock
  Query query;

  @BeforeEach
  public void setup() {
    Mockito.doNothing().when(entityManager).joinTransaction();
    Mockito.when(
        entityManager.createNativeQuery(
            Mockito.nullable(String.class), Mockito.nullable(String.class)))
        .thenReturn(query);

    Mockito.when(query.setParameter(Mockito.any(String.class), Mockito.any())).thenReturn(query);
  }

  @Test
  public void executeQueryTest() throws Exception {
    ListaResenas mockedResponse = ListaResenas.builder()
        .resenas(
            Arrays.asList(
                Resena.builder()
                    .nombreUsuario("string")
                    .texto("string")
                    .titulo("string")
                    .autor("string")
                    .build()))
        .build();

    Mockito.when(query.getSingleResult()).thenReturn(mockedResponse);

    ListaResenas response = repository.executeQuery();

    Assertions.assertEquals(mockedResponse, response);
  }

  @Test
  public void executeQueryNoResultTest() throws Exception {
    System.out.println("Inicio de prueba");
    Mockito.when(query.getSingleResult()).thenThrow(new NoResultException());

    ListaResenas response = repository.executeQuery();

    Assertions.assertNull(response);
  }
}
