package com.becdedalow.ms.resenas.domain.entity;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

public class LibroEntityTest {
    @Test
    public void PruebaLibro() {
        LibroEntity libro = null;
        assertNull(libro);
        libro = new LibroEntity();
        assertNotNull(libro);
        LibroEntityId libroId = new LibroEntityId();
        assertNull(libroId.getAutor());
        assertNull(libroId.getTitulo());
        libroId.setAutor("Anónimo");
        libroId.setTitulo("El cantar del mío Cid");
        assertEquals(libroId.getAutor(), "Anónimo");
        assertEquals(libroId.getTitulo(), "El cantar del mío Cid");
    }
}
