package com.becdedalow.ms.resenas.domain.repository;

import com.becdedalow.ms.resenas.domain.entity.ResenaEntity;
import com.becdedalow.ms.resenas.domain.entity.ResenaEntityId;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ResenaEntityRepositoryTest {
  @Autowired
  ResenaEntityRepository resenaRepository;

  @Test
  public void repositoryCrudTest() {
    System.out.println("Inicio de prueba");
    ResenaEntityId resenaId = new ResenaEntityId();
    resenaId.setTitulo("string");
    resenaId.setAutor("string");
    resenaId.setNombreUsuario("string");

    ResenaEntity resena = new ResenaEntity();
    resena.setId(resenaId);

    resenaRepository.save(resena);
    ResenaEntity response = resenaRepository.findById(resenaId).orElse(null);
    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getId(), resena.getId());

    resenaRepository.delete(resena);

    Assertions.assertNull(resenaRepository.findById(resenaId).orElse(null));
  }

  @Test
  public void obtenerResenasTest() throws Exception {
    System.out.println("Inicio de prueba");
    ResenaEntityId resenaId = new ResenaEntityId();
    resenaId.setTitulo("string");
    resenaId.setAutor("string");
    resenaId.setNombreUsuario("string");

    ResenaEntity resena = new ResenaEntity();
    resena.setId(resenaId);

    resenaRepository.save(resena);

    resenaRepository.obtenerResenas("string", "string");
  }
}
