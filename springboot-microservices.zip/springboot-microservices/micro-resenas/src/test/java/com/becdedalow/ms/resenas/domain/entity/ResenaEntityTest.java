package com.becdedalow.ms.resenas.domain.entity;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

public class ResenaEntityTest {
    @Test
    public void ResenaIdTest() {
        ResenaEntityId resId1 = null;
        assertNull(resId1);
        resId1 = new ResenaEntityId();
        assertNotNull(resId1);
        resId1.setAutor("Anónimo");
        resId1.setTitulo("El lazarillo de Tormes");
        resId1.setNombreUsuario("administrador");
        assertNotNull(resId1.getAutor());
        assertNotNull(resId1.getNombreUsuario());
        assertNotNull(resId1.getTitulo());
        assertEquals(resId1.getAutor(), "Anónimo");
        assertEquals(resId1.getTitulo(), "El lazarillo de Tormes");
        assertEquals(resId1.getNombreUsuario(), "administrador");
    }

    @Test
    public void ResenaTest() {
        ResenaEntity resena1 = null;
        assertNull(resena1);
        resena1 = new ResenaEntity();
        assertNotNull(resena1);
        resena1.setTexto("Buen libro");
        assertEquals(resena1.getTexto(), "Buen libro");
        assertNull(resena1.getId());
        ResenaEntityId resId = new ResenaEntityId();
        resena1.setId(resId);
        assertNotNull(resena1.getId());

    }

    @Test
    public void ResenaCompletaTest() {
        ResenaEntityId resId1 = new ResenaEntityId();
        resId1.setAutor("Anónimo");
        resId1.setTitulo("El lazarillo de Tormes");
        resId1.setNombreUsuario("administrador");

        ResenaEntity resena1 = new ResenaEntity();
        resena1.setTexto("Buen libro");
        resena1.setId(resId1);

        assertNotNull(resena1);
        assertNotNull(resId1);
        assertNotNull(resena1.getId());
        assertEquals(resena1.getId().getAutor(), "Anónimo");
        assertEquals(resena1.getId().getTitulo(), "El lazarillo de Tormes");
        assertEquals(resena1.getId().getNombreUsuario(), "administrador");
    }
}
