package com.becdedalow.ms.resenas.service;

import com.becdedalow.ms.resenas.domain.crud.LibroEntityService;
import com.becdedalow.ms.resenas.domain.crud.ResenaEntityService;
import com.becdedalow.ms.resenas.domain.model.Libro;
import com.becdedalow.ms.resenas.domain.model.ListaResenas;
import com.becdedalow.ms.resenas.domain.model.ListaResenasAux;
import com.becdedalow.ms.resenas.domain.model.Resena;
import com.becdedalow.ms.resenas.domain.repository.ObtenerCualquierResenaRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.jdbc.LobRetrievalFailureException;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class ResenasService {

  private final LibroEntityService libroEntityService;
  private final ObtenerCualquierResenaRepository obtenerCualquierResenaRepository;
  private final ResenaEntityService resenaEntityService;

  public ListaResenas obtenerResenas(String titulo, String autor) throws Exception {

    log.debug("Using method executeObtenerResenas");

    ListaResenas resenas = null;
    System.out.println("Iniciando método de obtenerResenas");
    try {
      System.out.println("iniciando búsqueda para obtener todas las reseñas del libro : " + titulo + " de " + autor);
      resenas = obtenerCualquierResenaRepository.executeQuery2(titulo, autor);
      System.out.println("Finalizada la llamada al método");
    } catch (Exception e) {

      log.error(e.getMessage(), e);
    }
    System.out.println("Finalizado el proceso de búsqueda");
    return resenas;
  }

  public ListaResenas obtenerTodasResenas() throws Exception {
    log.debug("Using method executeObtenerTodasResenas");

    ListaResenas Resenas = null;
    System.out.println("Iniciando método de obtenerTodasResenas");
    try {
      System.out.println("iniciando búsqueda para obtener todas las reseñas");
      Resenas = obtenerCualquierResenaRepository.executeQuery();
      System.out.println("Finalizada la llamada al método");
    } catch (Exception e) {

      log.error(e.getMessage(), e);
    }
    System.out.println("Finalizado el proceso de búsqueda");
    return Resenas;
  }

  public void enviar(Resena resena) throws Exception {

    log.debug("Using method executeEnviar");

    Libro libro = null;

    Resena res = null;

    Resena resenaCompr = null;

    System.out.println("Iniciando método de nombre enviar");
    try {

      System.out.println("Iniciando búsqueda del libro que se corresponde con la reseña");
      libro = libroEntityService.findById(resena.getTitulo(), resena.getAutor());
      System.out.println("Respuesta de la búsqueda obtenida");
    } catch (Exception e) {

      log.error(e.getMessage(), e);
    }
    System.out.println("Búsqueda sin resultados en la base de datos");
    if (libro == null) {
      try {
        System.out.println("Iniciando creación del registro del libro en la base de datos");
        libroEntityService.create(new Libro(resena.getTitulo(), resena.getAutor()));
        System.out.println("Creación del registro realizado exitosamente");
      } catch (Exception e) {

        log.error(e.getMessage(), e);
      }
    }
    try {
      System.out.println("Iniciando proceso de búsqueda de la reseña en la base de datos");
      resenaCompr = resenaEntityService.findById(resena.getTitulo(), resena.getAutor(), resena.getNombreUsuario());
      System.out.println("Proceso de guardado del registro realizado con éxito");
    } catch (Exception e) {

      log.error(e.getMessage(), e);
    }
    if (resenaCompr != null) {
      System.out.println("Búsqueda sin resultados en la base de datos");
      try {
        System.out.println("Iniciando creación del registro de la reseña en la base de datos");
        res = resenaEntityService.create(resena);
        System.out.println("Proceso de guardado del registro realizado con éxito");
      } catch (Exception e) {

        log.error(e.getMessage(), e);
      }
    } else {
      System.out.println("Búsqueda con resultado en la base de datos");
      try {
        System.out.println("Iniciando actualización del registro de la reseña en la base de datos");
        res = resenaEntityService.update(
            resena.getNombreUsuario(), resena.getTitulo(), resena.getAutor(), resena.getTexto());
        System.out.println("Proceso de actualización del registro realizado exitosamente");
      } catch (Exception e) {

        log.error(e.getMessage(), e);
      }
    }
  }

  public void eliminarResena(String autor, String titulo, String usuario) throws Exception {

    log.debug("Using method executeEliminarResena");
    System.out.println("Iniciando proceso de eliminación de la reseña indicada");
    try {
      System.out.println("Iniciando eliminación de la reseña");
      resenaEntityService.remove(usuario, titulo, autor);
      System.out.println("Finalizada la eliminación de la reseña");
    } catch (Exception e) {

      log.error(e.getMessage(), e);
    }
    System.out.println("Proceso de eliminación de la reseña finalizado");
  }
}
