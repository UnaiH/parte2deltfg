package com.becdedalow.ms.resenas.domain.repository;

import com.becdedalow.ms.resenas.domain.entity.ResenaEntity;
import com.becdedalow.ms.resenas.domain.entity.ResenaEntityId;
import com.becdedalow.ms.resenas.domain.model.ListaResenas;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ResenaEntityRepository
                extends JpaRepository<ResenaEntity, ResenaEntityId>, JpaSpecificationExecutor<ResenaEntity> {
        @Query(value = "SELECT nombreUsuario, texto FROM Resena where titulo = :titulo AND autor = :autor", nativeQuery = true)
        ListaResenas obtenerResenas(@Param("titulo") String titulo, @Param("autor") String autor)
                        throws Exception;
}
