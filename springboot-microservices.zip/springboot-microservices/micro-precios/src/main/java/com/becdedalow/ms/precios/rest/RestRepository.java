package com.becdedalow.ms.precios.rest;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.ctc.wstx.shaded.msv_core.util.Util;

@Component
public class RestRepository {
        @GetMapping("/books")
        public static String tPrecios(@RequestParam(name = "q", required = true) String q,
                        @RequestParam(name = "inauthor", required = true) String inauthor,
                        @RequestParam(name = "key", required = true) String key) throws IOException {
                q = q.replace(" ", "_");
                String url1 = "https://www.googleapis.com/books/v1/volumes?q=" + q + "&inauthor:" + inauthor
                                + "&key=" + key;
                URL url = new URL(url1);
                System.out.println("La url que se usará es la siguiente: " + url1);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                String respuesta = "";
                con.setRequestMethod("GET");
                int codigo = con.getResponseCode();
                if (codigo == 200) {
                        InputStream input = con.getInputStream();
                        StringBuffer buffer = new StringBuffer();
                        if (input == null) {
                                respuesta = "";
                        } else {
                                BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                                String line;
                                // Se almacena la respuesta el StringBuffer si hay otra linea
                                while ((line = reader.readLine()) != null) {
                                        buffer.append(line + "\n");
                                }
                                // Si la longitud de buffer fuera 0 se devolveria una lista vacia
                                if (buffer.length() == 0) {
                                        respuesta = "";
                                }
                                // Se convierte el valor de la variable buffer en un String.
                                respuesta = buffer.toString();
                                // Si la conexion no es null se cierra la conexion a la api
                                if (con != null) {
                                        con.disconnect();
                                }
                                // Si reader no es null se cierra la conexion de reader.
                                if (reader != null) {
                                        try {
                                                reader.close();
                                        } catch (IOException e) {
                                                e.printStackTrace();
                                        }
                                }
                        }
                }
                return respuesta;
        }

        @GetMapping("/books")
        public String mPrecios(@RequestParam(name = "q", required = true) String q,
                        @RequestParam(name = "inauthor", required = true) String inauthor,
                        @RequestParam(name = "key", required = true) String key) throws IOException {
                q = q.replace(" ", "_");
                String url1 = "https://www.googleapis.com/books/v1/volumes?q=" + q + "&inauthor=" + inauthor
                                + "&key=" + key;
                url1 = url1.replace(" ", "");
                URL url = new URL(url1);
                System.out.println("La url que se usará es la siguiente: " + url1);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                String respuesta = "";
                con.setRequestMethod("GET");
                int codigo = con.getResponseCode();
                if (codigo == 200) {
                        InputStream input = con.getInputStream();
                        StringBuffer buffer = new StringBuffer();
                        if (input == null) {
                                respuesta = "";
                        } else {
                                BufferedReader reader = new BufferedReader(new InputStreamReader(input));
                                String line;
                                // Se almacena la respuesta el StringBuffer si hay otra linea
                                while ((line = reader.readLine()) != null) {
                                        buffer.append(line + "\n");
                                }
                                // Si la longitud de buffer fuera 0 se devolveria una lista vacia
                                if (buffer.length() == 0) {
                                        respuesta = "";
                                }
                                // Se convierte el valor de la variable buffer en un String.
                                respuesta = buffer.toString();
                                // Si la conexion no es null se cierra la conexion a la api
                                if (con != null) {
                                        con.disconnect();
                                }
                                // Si reader no es null se cierra la conexion de reader.
                                if (reader != null) {
                                        try {
                                                reader.close();
                                        } catch (IOException e) {
                                                e.printStackTrace();
                                        }
                                }
                        }
                }
                return respuesta;
        }
}
