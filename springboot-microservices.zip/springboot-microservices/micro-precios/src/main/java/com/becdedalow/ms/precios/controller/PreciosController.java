package com.becdedalow.ms.precios.controller;

import com.becdedalow.ms.precios.domain.model.LibroAuxiliar;
import com.becdedalow.ms.precios.domain.model.ListaLibros;
import com.becdedalow.ms.precios.service.PreciosService;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class PreciosController {
  private final PreciosService preciosService;

  @GetMapping("/obtenerEnlaces")
  public ResponseEntity<ListaLibros> obtenerEnlaces(
      @RequestParam(name = "titulo", required = true) String titulo,
      @RequestParam(name = "autor", required = true) String autor) {

    System.out.println("Petición recibida para el método obtenerEnlaces desde el frontend para el libro con autor: "
        + autor + " y título: " + titulo);
    log.debug("Start of call to PreciosController - obtenerEnlaces with parameters: " + "titulo={}" + " - "
        + "apellidos={}" + " - " + "nombre={}", titulo, autor);

    List<String> errorParams = new ArrayList<>();
    if (Objects.isNull(titulo)) {
      errorParams.add("titulo");
    }
    if (Objects.isNull(autor)) {
      errorParams.add("autor");
    }

    if (!errorParams.isEmpty()) {
      System.out.println("Problemas en los parámetros recibidos. Se procede a detener la ejecución del método");
      return ResponseEntity.badRequest().build();
    }

    ListaLibros response = null;
    String[] partes = autor.split(" ");
    String nombre = partes[0];
    String apellidos = partes[1];
    if (partes.length > 2) {
      apellidos = apellidos + "_" + partes[2];
    }
    try {
      System.out
          .println("Llamando al método obtenerEnlaces para el libro con título: " + titulo + " y autor: " + nombre
              + "_" + apellidos + " desde el controller");
      response = preciosService.obtenerEnlaces(titulo, apellidos, nombre);
      System.out.println("Finalizada llamada del método obtenerEnlaces");
    } catch (Exception e) {
      log.error("Exception: {0}", e);
    }

    log.debug("End of call to PreciosController - obtenerEnlaces" + " with response={}", response);

    if (response == null) {
      System.out.println("La respuesta del método obtenerEnlaces ha sido nula");
      return ResponseEntity.notFound().build();
    } else {
      System.out.println("Respuesta recibida del método obtenerEnlaces con el número de respuestas válidas siguientes: "
          + response.getLibros().size());
      ResponseEntity respuesta = ResponseEntity.status(200).body(response);
      System.out.println("Tiene cuerpo " + respuesta.hasBody());
      return respuesta;
    }
  }

  @GetMapping("/mejorPrecio")
  public ResponseEntity<LibroAuxiliar> mejorPrecio(
      @RequestParam(name = "titulo", required = true) String titulo,
      @RequestParam(name = "autor", required = true) String autor) {

    System.out.println("Petición recibida para el método mejorPrecio desde el frontend para el libro con el título: "
        + titulo + " y el autor: " + autor);

    log.debug("Start of call to PreciosController - mejorPrecio with parameters: " + "titulo={}" + " - "
        + "autor={}", titulo, autor);

    List<String> errorParams = new ArrayList<>();
    if (Objects.isNull(titulo)) {
      errorParams.add("titulo");
    }
    if (Objects.isNull(autor)) {
      errorParams.add("autor");
    }

    if (!errorParams.isEmpty()) {
      System.out.println("Problema en los parámetros recibidos. Se procede a detener la ejecución del método");
      return ResponseEntity.badRequest().build();
    }

    LibroAuxiliar response = null;
    String[] partes = autor.split(" ");
    String nombre = partes[0];
    String apellidos = partes[1];
    if (partes.length > 2) {
      apellidos = apellidos + "_" + partes[2];
    }

    try {
      System.out.println(
          "Realizando llamada al método mejorPrecio para el libro con el título: " + titulo + " y autor: " + nombre
              + "_" + apellidos + " desde el controller");
      response = preciosService.mejorPrecio(titulo, apellidos, nombre);
      System.out.println("Llamada al método mejorPrecio finalizada con éxito");

    } catch (Exception e) {
      log.error("Exception: {0}", e);
    }

    log.debug("End of call to PreciosController - mejorPrecio" + " with response={}", response);

    if (response == null) {
      System.out.println("La respuesta obtenida del método mejorPrecio ha sido nula");
      return ResponseEntity.notFound().build();
    } else {
      System.out.println("Respuesta obtenida del método mejorPrecio con el precio: " + response.getPrecio()
          + " y el enlace: " + response.getEnlace());
      return ResponseEntity.ok().body(response);
    }
  }
}
