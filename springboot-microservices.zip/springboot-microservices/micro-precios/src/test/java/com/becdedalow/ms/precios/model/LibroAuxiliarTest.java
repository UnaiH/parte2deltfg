package com.becdedalow.ms.precios.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.becdedalow.ms.precios.domain.model.LibroAuxiliar;

public class LibroAuxiliarTest {
    @Test
    public void pruebaLibroAuxiliar() {
        LibroAuxiliar libro = null;
        assertNull(libro);
        libro = new LibroAuxiliar();
        assertNotNull(libro);
        assertNull(libro.getEnlace());
        assertNull(libro.getPrecio());
        libro.setEnlace("https://www.google.com");
        libro.setPrecio("0.00");
        assertEquals(libro.getEnlace(), "https://www.google.com");
        assertEquals(libro.getPrecio(), "0.00");
        assertTrue(Double.parseDouble(libro.getPrecio()) == 0.00);
        libro.setPrecio("5.35");
        assertTrue(Double.parseDouble(libro.getPrecio()) > 5);
        assertTrue(Double.parseDouble(libro.getPrecio()) < 6);
        assertTrue(Double.parseDouble(libro.getPrecio()) == 5.35);
    }
}
