package com.becdedalow.ms.usuarios.controller;

import com.becdedalow.ms.usuarios.domain.model.Usuario;
import com.becdedalow.ms.usuarios.service.UsuariosService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@SpringBootTest
public class UsuariosControllerTest {
  @Autowired
  private UsuariosController usuariosController;

  @MockBean
  private UsuariosService usuariosService;

  @Test
  public void eliminarUsuarioTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doNothing().when(usuariosService).eliminarUsuario(Mockito.nullable(String.class));

    ResponseEntity<Void> response = usuariosController.eliminarUsuario("string");

    Assertions.assertNotNull(response);
    Assertions.assertFalse(response.hasBody());
  }

  @Test
  public void eliminarUsuarioExceptionTest() throws Exception {
    System.out.println("Inicio de prueba");
    Mockito.doThrow(new Exception())
        .when(usuariosService)
        .eliminarUsuario(Mockito.nullable(String.class));

    ResponseEntity<Void> response = usuariosController.eliminarUsuario("string");

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.OK);
  }

  @Test
  public void eliminarUsuarioNullParamsTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doNothing().when(usuariosService).eliminarUsuario(Mockito.nullable(String.class));

    ResponseEntity<Void> response = usuariosController.eliminarUsuario(null);

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
  }

  @Test
  public void inicioSesionTest() throws Exception {
    System.out.println("Inicio de prueba 1");

    Mockito.doNothing()
        .when(usuariosService)
        .inicioSesion(Mockito.nullable(String.class), Mockito.nullable(String.class));

    ResponseEntity<Void> response = usuariosController
        .inicioSesion("administrador", "administrador", null);

    Assertions.assertNotNull(response);
    Assertions.assertFalse(response.hasBody());
  }

  @Test
  public void inicioSesionExceptionTest() throws Exception {
    System.out.println("Inicio de prueba 2");
    Mockito.doThrow(new Exception())
        .when(usuariosService)
        .inicioSesion(Mockito.nullable(String.class), Mockito.nullable(String.class));

    ResponseEntity<Void> response = usuariosController
        .inicioSesion("administrador", "administrador", null);

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.OK);
  }

  @Test
  public void inicioSesionNullParamsTest() throws Exception {
    System.out.println("Inicio de prueba 3");

    Mockito.doNothing()
        .when(usuariosService)
        .inicioSesion(Mockito.nullable(String.class), Mockito.nullable(String.class));

    ResponseEntity<Void> response = usuariosController
        .inicioSesion(null, null, null);

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
  }

  @Test
  public void registroUsuariosTest() throws Exception {
    System.out.println("Inicio de prueba 4");

    Mockito.doNothing().when(usuariosService).registroUsuarios(Mockito.nullable(Usuario.class));

    ResponseEntity<Void> response = usuariosController.registroUsuarios("Prueba4", "Prueba4");

    Assertions.assertNotNull(response);
    Assertions.assertFalse(response.hasBody());
  }

  @Test
  public void registroUsuariosExceptionTest() throws Exception {
    System.out.println("Inicio de prueba 5");
    Mockito.doThrow(new Exception())
        .when(usuariosService)
        .registroUsuarios(Mockito.nullable(Usuario.class));

    ResponseEntity<Void> response = usuariosController.registroUsuarios("Prueba5", "Prueba5");

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.OK);
  }

  @Test
  public void registroUsuariosNullParamsTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doNothing().when(usuariosService).registroUsuarios(Mockito.nullable(Usuario.class));

    ResponseEntity<Void> response = usuariosController.registroUsuarios(null, null);

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
  }
}
