package com.becdedalow.ms.usuarios.service;

import com.becdedalow.ms.usuarios.domain.crud.UsuarioEntityService;
import com.becdedalow.ms.usuarios.domain.model.Usuario;

import static org.junit.Assert.assertThrows;

import java.util.Optional;

import org.jeasy.random.EasyRandom;
import org.jeasy.random.EasyRandomParameters;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class UsuariosServiceTest {
  @InjectMocks
  @Spy
  private UsuariosService usuariosService;

  @Mock
  private UsuarioEntityService usuarioEntityService;

  private EasyRandom generator;

  @BeforeEach
  public void setUp() {
    System.out.println("Inicio de prueba");
    EasyRandomParameters parameters = new EasyRandomParameters();
    parameters.overrideDefaultInitialization(true);
    generator = new EasyRandom();
  }

  @Test
  public void eliminarUsuarioTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doNothing().when(usuarioEntityService).remove(Mockito.nullable(String.class));

    usuariosService.eliminarUsuario("string");
  }

  @Test
  public void eliminarUsuarioEliminarExceptionTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doThrow(new Exception())
        .when(usuarioEntityService)
        .remove(Mockito.nullable(String.class));

    usuariosService.eliminarUsuario("string");
  }

  @Test
  public void inicioSesionTest() throws Exception {
    System.out.println("Inicio de prueba");
    Usuario usu = new Usuario();
    usu.setNombreUsuario("administrador");
    usu.setPassword("administrador");

    Mockito.when(usuarioEntityService.findById(Mockito.anyString()))
        .thenReturn(usu);

    usuariosService.inicioSesion("administrador", "administrador");
  }

  @Test
  public void inicioSesionIniciarSesionExceptionTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doThrow(new Exception())
        .when(usuarioEntityService)
        .findById(Mockito.nullable(String.class));

    assertThrows(Exception.class, () -> {
      usuariosService.inicioSesion(null, null);
    });
  }

  @Test
  public void registroUsuariosTest() throws Exception {
    System.out.println("Inicio de prueba");
    Usuario usu = new Usuario();
    usu.setNombreUsuario("usuarioPrueba123456");
    usu.setPassword("usuarioPrueba123456");

    Mockito.doReturn(usu)
        .when(usuarioEntityService)
        .findById(null);

    Mockito.doReturn(generator.nextObject(Usuario.class))
        .when(usuarioEntityService)
        .create(Mockito.nullable(Usuario.class));

    usuariosService.registroUsuarios(usu);
  }

  @Test
  public void registroUsuariosComprobarUsuarioExceptionTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doThrow(new Exception())
        .when(usuarioEntityService)
        .findById(Mockito.nullable(String.class));

    Mockito.doReturn(generator.nextObject(Usuario.class))
        .when(usuarioEntityService)
        .create(Mockito.nullable(Usuario.class));

    usuariosService.registroUsuarios(generator.nextObject(Usuario.class));
  }

  @Test
  public void registroUsuariosRegistrarExceptionTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doReturn(generator.nextObject(Usuario.class))
        .when(usuarioEntityService)
        .findById(Mockito.anyString());

    Mockito.doThrow(new Exception())
        .when(usuarioEntityService)
        .create(Mockito.nullable(Usuario.class));

    assertThrows(Exception.class, () -> {
      usuariosService.registroUsuarios(generator.nextObject(Usuario.class));
    });
  }
}
