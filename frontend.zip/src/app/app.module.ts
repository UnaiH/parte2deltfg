import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { InterceptorService } from './interceptor.service';
// Components
import { NgSelectModule } from '@ng-select/ng-select';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
// Angular Material
import { MatPaginatorModule, MatTableModule } from '@angular/material';
// Pipes
import { DatePipe } from '@angular/common';
import { SafePipe } from './shared/pipes/safe.pipe';
// Deda Native Components
import { DedaButtonComponent } from './components/deda-button/deda-button.component';
import { DedaTextBoxComponent } from './components/deda-text-box/deda-text-box.component';
import { DedaPasswordComponent } from './components/deda-password/deda-password.component';
import { DedaTextBlockComponent } from './components/deda-text-block/deda-text-block.component';
import { DedaGridComponent } from './components/deda-grid/deda-grid.component';
import { DedaCheckBoxComponent } from './components/deda-check-box/deda-check-box.component';
import { DedaRadioButtonComponent } from './components/deda-radio-button/deda-radio-button.component';
import { DedaLinkComponent } from './components/deda-link/deda-link.component';
import { DedaImageComponent } from './components/deda-image/deda-image.component';
import { DedaVideoComponent } from './components/deda-video/deda-video.component';
import { DedaFormComponent } from './components/deda-form/deda-form.component';
import { DedaTableComponent } from './components/deda-table/deda-table.component';
import { TablaComponent } from './components/tabla/tabla.component';
import { DedaSelectComponent } from './components/deda-select/deda-select.component';
import { DedaPaginationComponent } from './components/deda-pagination/deda-pagination.component';


import { AppComponent } from './app.component';
import { todosEnlacesComponent } from './pages/todosEnlaces/todosEnlaces.component';
import { inicioSesionComponent } from './pages/inicioSesion/inicioSesion.component';
import { CabeceraComponent } from './pages/Cabecera/Cabecera.component';
import { menuPrincipalComponent } from './pages/menuPrincipal/menuPrincipal.component';
import { escribirResenaComponent } from './pages/escribirResena/escribirResena.component';
import { RegistroComponent } from './pages/Registro/Registro.component';
import { VerPrecioComponent } from './pages/VerPrecio/VerPrecio.component';
import { VerResenasComponent } from './pages/VerResenas/VerResenas.component';
import { TodasResenasComponent } from './pages/TodasResenas/TodasResenas.component';



const routes: Routes = [
  {
    path: 'todosEnlaces',
    component: todosEnlacesComponent
  },
  {
    path: 'inicioSesion',
    component: inicioSesionComponent
  },
  {
    path: 'menuPrincipal',
    component: menuPrincipalComponent
  },
  {
    path: '',
    component: menuPrincipalComponent
  },
  {
    path: 'escribirResena',
    component: escribirResenaComponent
  },
  {
    path: 'Registro',
    component: RegistroComponent
  },
  {
    path: 'VerPrecio',
    component: VerPrecioComponent
  },
  {
    path: 'VerResenas',
    component: VerResenasComponent
  },
  {
    path: 'TodasResenas',
    component: TodasResenasComponent
  },
];

@NgModule({
  declarations: [
    todosEnlacesComponent,
    inicioSesionComponent,
    CabeceraComponent,
    menuPrincipalComponent,
    escribirResenaComponent,
    RegistroComponent,
    VerPrecioComponent,
    VerResenasComponent,
    TodasResenasComponent,
    AppComponent,
    SafePipe,
    DedaButtonComponent,
    DedaTextBoxComponent,
    DedaPasswordComponent,
    DedaTextBlockComponent,
    DedaGridComponent,
    DedaCheckBoxComponent,
    DedaRadioButtonComponent,
    DedaLinkComponent,
    DedaImageComponent,
    DedaVideoComponent,
    DedaFormComponent,
    DedaTableComponent,
    DedaSelectComponent,
    DedaPaginationComponent,
    TablaComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    NgSelectModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    NgMultiSelectDropDownModule.forRoot(),
    RouterModule.forRoot(routes),
    MatTableModule,
    MatPaginatorModule
  ],
  providers: [
    DatePipe,

    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true
    }
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule {

  constructor() {
  }


}
