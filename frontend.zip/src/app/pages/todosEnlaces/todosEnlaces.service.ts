import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { MatTabBody } from '@angular/material';


@Injectable({
  providedIn: 'root'
})
export class todosEnlacesService {


  constructor(private http: HttpClient) { }

  obtenerEnlaces(titulo, autor): Observable<any> {
    const httpOptions = {
      observe: 'body',
    };
    return this.http.get<any>(
      `${environment.backUrl}/precios/obtenerEnlaces?titulo=${titulo}&autor=${autor}`, { ...httpOptions, observe: 'response' }
    );
  }


}
