import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from 'src/app/data.service';
import { isNil, isNotNil } from 'src/app/shared/utils/utils';
import { BaseComponent } from 'src/app/shared/base.component';
import * as R from 'ramda';

import { VerPrecioService } from './VerPrecio.service';
import { AppComponent } from 'src/app/app.component';

@Component({
  selector: 'app-verprecio',
  templateUrl: './VerPrecio.component.html',
  styleUrls: ['./VerPrecio.component.css']
})
export class VerPrecioComponent extends BaseComponent implements OnInit {

  readonly PAGE_NAME = 'VerPrecio';
  public isNil = isNil;
  public isNotNil = isNotNil;

  public nombreAutor?: string;

  public apellidosAutor?: string;

  public autor?: string

  public titulo?: string;

  public enlace?: string;

  public precio?: string;

  public Libro?: {
    enlace?: string,
    precio?: string,
  } = {};

  public Warning?: {
    message?: string,
    code?: number,
  } = {};

  public Error?: {
    message?: string,
    code?: number,
  } = {};

  public Info?: {
    message?: string,
    code?: number,
  } = {};

  constructor(
    public myapp: AppComponent,
    public router: Router,
    private dataService: DataService,
    private VerPrecioService: VerPrecioService
  ) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
    const sourcePageAction: string = this.dataService.getSource();
    const args: any[] = this.dataService.getArgs();
    if (sourcePageAction) {
      try {
        if (args) {
          const body: object = this.dataService.getBody();
          Object.values(body).forEach(({ destination, value }) => {
            const fieldName = R.head(destination);
            const nestedFieldNames = R.tail(destination);
            this[fieldName] = R.assocPath(nestedFieldNames)(value)(this[fieldName]);
          });
        }
        this[sourcePageAction].apply(this, args || []);
      } catch (err) { }
    }
    this.autor=sessionStorage.getItem("autor");
    this.titulo=sessionStorage.getItem("titulo");
    this.cargarPrecio(this.autor, this.titulo);
  }

  ngAfterViewInit() {
    this.esconderBotones();
  }
  
  cargarPrecio(
    autor: string,
    titulo: string
  ) {
    console.log("Obteniendo el precio más bajo para el libro con título: "+titulo+ " y del autor: "+autor);
    this.VerPrecioService.mejorPrecio(titulo,
      autor).subscribe(
        ok => {
          this.Libro.enlace = ok.body.enlace;
          this.Libro.precio = ok.body.precio;
          this.precio=this.Libro.precio + "€";
          this.enlace=this.Libro.enlace;
          if(this.Libro.enlace=="" || this.Libro.enlace=="#"){
            alert("No se ha encontrado ningún precio para el libro");
            this.router.navigate(['menuPrincipal']);
          }
        },
        error => {
          this.Error2();
        }
      );
  }

  esconderBotones() {
    document.getElementById("btnInicio").hidden = false;
    if (sessionStorage.getItem("Iniciado")) {
      document.getElementById("btnIniciarSesion").hidden = true;
      document.getElementById("btnRegistrarse").hidden = true;
      document.getElementById("cerrarSesion").hidden = false;
    } else {
      document.getElementById("cerrarSesion").hidden = true;
      document.getElementById("btnIniciarSesion").hidden = false;
      document.getElementById("btnRegistrarse").hidden = true;
    }

  }

  Error2() {
    alert("No se ha encontrado el libro");


    this.router.navigate(['menuPrincipal']);
  }




  showWarning(message: string, code: number) {
    this.Warning.message = message;
    this.Warning.code = code;
  }

  showError(message: string, code: number) {
    this.Error.message = message;
    this.Error.code = code;
  }

  showInfo(message: string, code: number) {
    this.Info.message = message;
    this.Info.code = code;
  }

}
