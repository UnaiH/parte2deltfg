import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class VerPrecioService {


  constructor(private http: HttpClient) { }

  mejorPrecio(titulo: any, autor: any): Observable<any> {
    const httpOptions = {
      observe: 'body',
    };
    return this.http.get<any>(
      `${environment.backUrl}/precios/mejorPrecio?titulo=${titulo}&autor=${autor}`, { ...httpOptions, observe: 'response' }
    );
  }


}
