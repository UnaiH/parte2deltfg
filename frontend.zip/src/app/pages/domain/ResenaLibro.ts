import { Usuario } from './Usuario';
import { Libro } from './Libro';
import { DedaButtonComponent } from 'src/app/components/deda-button/deda-button.component';

export class ResenaLibro {
  usuario?: string;
  texto?: string;
  resenasUsuario?: Usuario[];
  resenasLibro?: Libro[];
}
