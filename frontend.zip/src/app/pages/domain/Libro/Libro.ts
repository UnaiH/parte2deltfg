import { Resena } from './../Resena/Resena';

export class Libro {
  constructor(
    public titulo?: string,
    public autor?: string,
    public Resenatitulo?: Libro[],
    public ResenatituloClause?: any,
  ) { }
}
