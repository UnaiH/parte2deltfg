import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Libro } from './Libro';

@Injectable({
  providedIn: 'root'
})
export class LibroService {

  public LibroBackUrl: string = environment.backUrl + '/' + 'Libro';


  constructor(private http: HttpClient) {
  }

  // Fetch all objects Libro
  getObjectsLibro(): Observable<Libro[]> {
    return this.http.get<Libro[]>(
      this.LibroBackUrl + 's'
    );
  }

  getObjectsLibroPag(
    page: number,
    size: number
  ): Observable<HttpResponse<any>> {
    return this.http.get<HttpResponse<any>>(
      this.LibroBackUrl + 's/' + page + '/' + size,
      { observe: 'response' }
    );
  }

  // Fetch objects Libro by id without relationships
  getObjectsLibroWithoutRelationships(): Observable<Libro[]> {
    return this.http.get<Libro[]>(
      this.LibroBackUrl + '/LibrosWithOutRelationships'
    );
  }

  getObjectsLibroWithoutRelationshipsPag(
    page: number,
    size: number
  ): Observable<HttpResponse<any>> {
    return this.http.get<HttpResponse<any>>(
      `${this.LibroBackUrl}sWithoutRelationships/${page + 1}/${size}`,
      { observe: 'response' }
    );
  }

  // Create object Libro
  createObjectLibro(
    objectLibro: Libro
  ): Observable<Libro> {
    return this.http.post(
      this.LibroBackUrl,
      objectLibro
    );
  }

  // Fetch object Libro by id
  getObjectLibroById(
    id: string
  ): Observable<Libro> {
    return this.http.get<Libro>(
      this.LibroBackUrl + '/' + id
    );
  }

  // Fetch object Libro by id without relationships
  getObjectLibroWithoutRelationships(
    id: string
  ): Observable<Libro> {
    return this.http.get<Libro>(
      this.LibroBackUrl + 'WithoutRelationships' + '/' + id
    );
  }

  // Update object Libro
  updateObjectLibro(
    objectLibro: Libro
  ): Observable<Libro> {
    return this.http.put<Libro>(
      this.LibroBackUrl + '/' + objectLibro.titulo,
      objectLibro
    );
  }

  // Delete object Libro
  deleteObjectLibro(
    id: string
  ): Observable<Libro> {
    return this.http.delete(
      this.LibroBackUrl + '/' + id
    );
  }

}
