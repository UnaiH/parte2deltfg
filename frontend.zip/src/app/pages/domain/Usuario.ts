
export class Usuario {
  password?: string;
  usuario?: string;
}
