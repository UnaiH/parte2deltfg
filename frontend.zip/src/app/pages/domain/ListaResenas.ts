
export class ListaResenas {
}
