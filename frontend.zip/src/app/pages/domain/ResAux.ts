
export class ResAux {
  usu?: string;
  res?: string;
  tit?: string;
  aut?: string;
}
