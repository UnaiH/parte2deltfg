import { Resena } from './../Resena/Resena';

export class Usuario {
  constructor(
    public nombreUsuario?: string,
    public password?: string,
    public ResenanombreUsuario?: Usuario[],
    public ResenanombreUsuarioClause?: any,
  ) { }
}
