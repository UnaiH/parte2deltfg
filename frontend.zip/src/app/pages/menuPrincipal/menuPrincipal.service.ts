import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class menuPrincipalService {


  constructor(private http: HttpClient) { }

  eliminarUsuario(usuario: any): Observable<any> {
    const data: string = JSON.stringify({
      usuario: usuario
    }, (k, v) => v === undefined ? null : v
    );
    const httpOptions = {
      observe: 'body',
    };
    return this.http.post<any>(
      `${environment.backUrl}/usuarios/eliminarUsuario?nombreUsuario=${usuario}`
      , { ...httpOptions, observe: 'response' }
    );
  }
}
