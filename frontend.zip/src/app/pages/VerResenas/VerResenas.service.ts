import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class VerResenasService {


  constructor(private http: HttpClient) { }

  eliminarResena(titulo: any, autor: any, usuario: any): Observable<any> {
    const data: string = JSON.stringify({
      autor: autor,
      titulo: titulo,
      usuario: usuario
    }, (k, v) => v === undefined ? null : v
    );
    const httpOptions = {
      observe: 'body',
    };
    return this.http.get<any>(
      `${environment.backUrl}/resenas/eliminarResena?titulo=${titulo}&autor=${autor}&usuario=${usuario}`
      , { ...httpOptions, observe: 'response' }
    );
  }

  obtenerResenas(autor: any, titulo: any): Observable<any> {
    const data: string = JSON.stringify({
      titulo: titulo,
      autor: autor
    }, (k, v) => v === undefined ? null : v
    );
    const httpOptions = {
      observe: 'body',
    };
    return this.http.get<any>(
      `${environment.backUrl}/resenas/obtenerResenas?titulo=${titulo}&autor=${autor}`
      , { ...httpOptions, observe: 'response' }
    );
  }
}
