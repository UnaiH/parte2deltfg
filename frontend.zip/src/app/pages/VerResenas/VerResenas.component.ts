import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from 'src/app/data.service';
import { isNil, isNotNil } from 'src/app/shared/utils/utils';
import { BaseComponent } from 'src/app/shared/base.component';
import * as R from 'ramda';

import { VerResenasService } from './VerResenas.service';
import { AppComponent } from 'src/app/app.component';
import { ResenaLibro } from '../domain/ResenaLibro';
import { ResenaService } from '../domain/Resena/Resena.service';

@Component({
  selector: 'app-verresenas',
  templateUrl: './VerResenas.component.html',
  styleUrls: ['./VerResenas.component.css']
})
export class VerResenasComponent extends BaseComponent implements OnInit {

  readonly PAGE_NAME = 'VerResenas';
  public isNil = isNil;
  public isNotNil = isNotNil;

  public titulo?: string;

  public autor?: string;

  public columns: string[] = ["Usuario","Texto","Accion"];

  public administrador?: string;

  public listaResenas?: Array<{
    usuario?: string,
    texto?: string,
  }> = [];

  public Warning?: {
    message?: string,
    code?: number,
  } = {};

  public Error?: {
    message?: string,
    code?: number,
  } = {};

  public Info?: {
    message?: string,
    code?: number,
  } = {};

  constructor(
    public myapp: AppComponent,
    public router: Router,
    private dataService: DataService,
    private VerResenasService: VerResenasService
  ) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
    const sourcePageAction: string = this.dataService.getSource();
    const args: any[] = this.dataService.getArgs();
    if (sourcePageAction) {
      try {
        if (args) {
          const body: object = this.dataService.getBody();
          Object.values(body).forEach(({ destination, value }) => {
            const fieldName = R.head(destination);
            const nestedFieldNames = R.tail(destination);
            this[fieldName] = R.assocPath(nestedFieldNames)(value)(this[fieldName]);
          });
        }
        this[sourcePageAction].apply(this, args || []);
      } catch (err) { }
    }
  }
  ngAfterViewInit() {
    this.esconderBotones();
    this.obtenerResenas(this.titulo, this.autor);
    if (sessionStorage.getItem("admin") == "true") {
      this.administrador=sessionStorage.getItem("admin");
    }
  }

  esconderBotones() {
    document.getElementById("btnInicio").hidden = false;
    if (sessionStorage.getItem("Iniciado")) {
      document.getElementById("btnIniciarSesion").hidden = true;
      document.getElementById("btnRegistrarse").hidden = true;
      document.getElementById("cerrarSesion").hidden = false;
    } else {
      document.getElementById("cerrarSesion").hidden = true;
      document.getElementById("btnIniciarSesion").hidden = false;
      document.getElementById("btnRegistrarse").hidden = true;
    }

  }

  obtenerResenas(titulo: string,autor: string) {
    console.log("Obteniendo las reseñas del libro con título: "+titulo+ " y del autor: "+autor);
    this.VerResenasService.obtenerResenas(autor,titulo).subscribe(
        ok => {
          if(ok.body.resenas.length == 0 || ok.body.resenas == null){
            alert("No se han encontrado reseñas");
            this.router.navigate(['menuPrincipal']);
          }else{
            this.listaResenas = ok.body.resenas;
          }
        },
        error => {
          this.Error2();
        }
      );
  }

  Error2() {
    alert("No se han encontrado reseñas");

    this.router.navigate(['menuPrincipal']);
  }

  eliminarResena(
    autor: string,
    titulo: string,
    usuario: string
  ) {
    console.log("Eliminando la reseña seleccionada escrita por el usuario: "+usuario);
    this.VerResenasService.eliminarResena(titulo,
      autor,
      usuario).subscribe(
        ok => {
          alert("Eliminado correctamente");
          this.router.navigate(['menuPrincipal']);
        },
        error => { }
      );
  }


  menuPrincipal_VerResena_NFmenuPrincipalVerResenasVerResena() {
    const body: any = this.dataService.getBody();

    this.autor = body.autor;
    this.titulo = body.titulo;
  }



  showWarning(message: string, code: number) {
    this.Warning.message = message;
    this.Warning.code = code;
  }

  showError(message: string, code: number) {
    this.Error.message = message;
    this.Error.code = code;
  }

  showInfo(message: string, code: number) {
    this.Info.message = message;
    this.Info.code = code;
  }

}
