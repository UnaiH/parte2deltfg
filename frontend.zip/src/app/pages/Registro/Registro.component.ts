import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from 'src/app/data.service';
import { isNil, isNotNil } from 'src/app/shared/utils/utils';
import { BaseComponent } from 'src/app/shared/base.component';
import * as R from 'ramda';

import { RegistroService } from './Registro.service';
import { AppComponent } from 'src/app/app.component';

@Component({
  selector: 'app-registro',
  templateUrl: './Registro.component.html',
  styleUrls: ['./Registro.component.css']
})
export class RegistroComponent extends BaseComponent implements OnInit {

  readonly PAGE_NAME = 'Registro';
  public isNil = isNil;
  public isNotNil = isNotNil;

  public usuario?: string;

  public contrasena?: string;

  public confContrasena?: string;

  public Warning?: {
    message?: string,
    code?: number,
  } = {};

  public Error?: {
    message?: string,
    code?: number,
  } = {};

  public Info?: {
    message?: string,
    code?: number,
  } = {};

  public valido?: boolean;

  constructor(
    public myapp: AppComponent,
    public router: Router,
    private dataService: DataService,
    private RegistroService: RegistroService
  ) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
    const sourcePageAction: string = this.dataService.getSource();
    const args: any[] = this.dataService.getArgs();
    if (sourcePageAction) {
      try {
        if (args) {
          const body: object = this.dataService.getBody();
          Object.values(body).forEach(({ destination, value }) => {
            const fieldName = R.head(destination);
            const nestedFieldNames = R.tail(destination);
            this[fieldName] = R.assocPath(nestedFieldNames)(value)(this[fieldName]);
          });
        }
        this[sourcePageAction].apply(this, args || []);
      } catch (err) { }
    }
  }
  ngAfterViewInit() {
    this.esconderBotones();
  }
  es_numerico(str){
    return /^\d+$/.test(str);
  }

  registrarse(
    usuario: string,
    confContrasena: string,
    contrasena: string,
    valido: boolean
  ) {
    console.log("Realizando las comprobaciones de registro de usuario para el usuario: "+usuario);
    if(usuario!=null && usuario!="" && confContrasena!=null && confContrasena!="" && contrasena!=null && contrasena!=""){
      if (usuario == "administrador") {
        alert("No se puede registrar administrador porque ya existe");
      } else {
        if (usuario.length <= 255 && usuario.length >= 1) {
          if (contrasena.length > 10 && contrasena == confContrasena) {
            var siN = false;
            var siL = false;
            var sil = false;
            var siE = false;
            for (var letra = 0; letra < contrasena.length; letra++) {
              if (this.es_numerico(contrasena.charAt(letra))) {
                siN = true;
              } else {
                if (/[a-z]/.test(contrasena.charAt(letra))) {
                  sil = true;
                } else {
                  if (/[A-Z]/.test(contrasena.charAt(letra))) {
                    siL = true;
                  } else {
                    siE = true;
                  }
                }
              }
            }
            if (siN && sil && siL && siE) {
              valido = true;
            } else {
              alert("Contraseñas no válido debe tener al menos un caracter especial, un número, una letra minuscula y una letra mayuscula");
            }
          } else {
            alert("Contraseñas no coincide o no mide al menos 10 caracteres");
          }
        } else {
          alert("Usuario no válido tiene que tener al menos un caracter y como mucho 255");
        }
      }

      if (valido === true) {
        console.log("Realizando registro para el usuario: "+usuario);
        this.RegistroService.registrarse(contrasena,
          usuario).subscribe(
            ok => {
              sessionStorage.setItem('usuario', JSON.stringify(usuario !== undefined ? usuario : null));
              sessionStorage.setItem('Iniciado', 'true');
              this.router.navigate(['menuPrincipal']);
            },
            error => {
              alert("Error al registrar el usuario: "+usuario);
              sessionStorage.setItem('borrarUsuario', 'true');
              this.router.navigate(['menuPrincipal']);
            }
          );
        return;
      }

      if (valido === false) {
        return;
      }
    }else{
      alert("Rellene todos los campos para poder registrar el usuario")
    }
  }

  esconderBotones() {
    document.getElementById("btnRegistrarse").hidden = true;
    document.getElementById("btnIniciarSesion").hidden = false;
    document.getElementById("cerrarSesion").hidden = true;
    document.getElementById("btnInicio").hidden = false;
  }



  showWarning(message: string, code: number) {
    this.Warning.message = message;
    this.Warning.code = code;
  }

  showError(message: string, code: number) {
    this.Error.message = message;
    this.Error.code = code;
  }

  showInfo(message: string, code: number) {
    this.Info.message = message;
    this.Info.code = code;
  }

}
