import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Usuario } from '../domain/Usuario/Usuario';


@Injectable({
  providedIn: 'root'
})
export class inicioSesionService {


  constructor(private http: HttpClient) { }

  iniciarSesion(usuario: any, contrasena: any): Observable<any> {
    const body = {
      usuario: usuario,
      contrasena: contrasena
    };
      const data: string = JSON.stringify({
        usuario: new Usuario(usuario,contrasena)
      }, (k, v) => v === undefined ? null : v
      );
      const httpOptions = {
        observe: 'body',
      };
      return this.http.post<any>(
        `${environment.backUrl}/usuarios/inicioSesion?nombreUsuario=${usuario}&contrasena=${contrasena}`
        , { ...httpOptions, observe: 'response' }
      );
  }


}
