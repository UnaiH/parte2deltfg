import * as R from 'ramda';

export const isNil = R.isNil;
export const isNotNil = R.complement(R.isNil);