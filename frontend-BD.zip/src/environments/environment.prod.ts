export const environment = {
  production: true,
  backUrl: 'http://localhost:8080'
};
