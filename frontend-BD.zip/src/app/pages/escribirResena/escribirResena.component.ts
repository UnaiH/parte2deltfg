import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from 'src/app/data.service';
import { isNil, isNotNil } from 'src/app/shared/utils/utils';
import { BaseComponent } from 'src/app/shared/base.component';
import * as R from 'ramda';

import { escribirResenaService } from './escribirResena.service';
import { AppComponent } from 'src/app/app.component';

@Component({
  selector: 'app-escribirresena',
  templateUrl: './escribirResena.component.html',
  styleUrls: ['./escribirResena.component.css']
})
export class escribirResenaComponent extends BaseComponent implements OnInit {

  readonly PAGE_NAME = 'escribirResena';
  public isNil = isNil;
  public isNotNil = isNotNil;

  public resena?: string;

  public titulo?: string;

  public usuario?: string;

  public Warning?: {
    message?: string,
    code?: number,
  } = {};

  public autor?: string;
  
  public texto?: string;

  public Error?: {
    message?: string,
    code?: number,
  } = {};

  public Info?: {
    message?: string,
    code?: number,
  } = {};

  constructor(
    public myapp: AppComponent,
    public router: Router,
    private dataService: DataService,
    private escribirResenaService: escribirResenaService
  ) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
    const sourcePageAction: string = this.dataService.getSource();
    const args: any[] = this.dataService.getArgs();
    if (sourcePageAction) {
      try {
        if (args) {
          const body: object = this.dataService.getBody();
          Object.values(body).forEach(({ destination, value }) => {
            const fieldName = R.head(destination);
            const nestedFieldNames = R.tail(destination);
            this[fieldName] = R.assocPath(nestedFieldNames)(value)(this[fieldName]);
          });
        }
        this[sourcePageAction].apply(this, args || []);
      } catch (err) { }
    }
  }

  ngAfterViewInit() {
    this.esconderBotones();
  }

  enviar(
    usuario: string,
    texto: string,
    titulo: string,
    autor: string
  ) {
    console.log("Guardando reseña en la base de datos");
    usuario = JSON.parse(sessionStorage.getItem('usuario'));

    this.escribirResenaService.enviar(usuario,  titulo, autor, texto).subscribe(ok => {
          this.router.navigate(['menuPrincipal']);
        },
        error => { alert("Error al escribir la reseña")}
      );
  }

  esconderBotones() {
    document.getElementById("btnInicio").hidden = false;
    if (sessionStorage.getItem("Iniciado")) {
      document.getElementById("btnIniciarSesion").hidden = true;
      document.getElementById("btnRegistrarse").hidden = true;
      document.getElementById("cerrarSesion").hidden = false;
    } else {
      document.getElementById("cerrarSesion").hidden = true;
      document.getElementById("btnIniciarSesion").hidden = false;
      document.getElementById("btnRegistrarse").hidden = true;
    }

  }

  menuPrincipal_escribirResena_NFmenuPrincipalescribirResenaescribirResena() {
    const body: any = this.dataService.getBody();

    this.titulo = body.titulo;
    this.autor = body.autor;
    this.usuario = body.usuario;
    this.texto = body.texto;
  }

  showWarning(message: string, code: number) {
    this.Warning.message = message;
    this.Warning.code = code;
  }

  showError(message: string, code: number) {
    this.Error.message = message;
    this.Error.code = code;
  }

  showInfo(message: string, code: number) {
    this.Info.message = message;
    this.Info.code = code;
  }

}
