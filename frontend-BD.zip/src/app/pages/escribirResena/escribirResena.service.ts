import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Resena } from '../domain/Resena';


@Injectable({
  providedIn: 'root'
})
export class escribirResenaService {


  constructor(private http: HttpClient) { }

  enviar(usuario: any, titulo: any, autor: any, texto: any): Observable<any> {
    const data: string = JSON.stringify({
      Resena: new Resena()
    }, (k, v) => v === undefined ? null : v
    );
    const httpOptions = {
      observe: 'body',
    };
    return this.http.get<any>(
      `${environment.backUrl}/resenas/enviar?titulo=${titulo}&autor=${autor}&usuario=${usuario}&texto=${texto}`
      , { ...httpOptions, observe: 'response' }
    );
  }


}
