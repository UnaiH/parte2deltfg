import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from 'src/app/data.service';
import { isNil, isNotNil } from 'src/app/shared/utils/utils';
import { BaseComponent } from 'src/app/shared/base.component';
import * as R from 'ramda';

import { todosEnlacesService } from './todosEnlaces.service';
import { AppComponent } from 'src/app/app.component';
import { LibroAuxiliar } from '../domain/LibroAuxiliar';
import { ListaLibros } from '../domain/ListaLibros';
import { MostrarLibro } from '../domain/MostrarLibro';

@Component({
  selector: 'app-todosenlaces',
  templateUrl: './todosEnlaces.component.html',
  styleUrls: ['./todosEnlaces.component.css']
})
export class todosEnlacesComponent extends BaseComponent implements OnInit {

  readonly PAGE_NAME = 'todosEnlaces';
  public isNil = isNil;
  public isNotNil = isNotNil;

  public columns: string[] = ["Precio","Enlace"];

  public titulo?: string;

  public autor?: string;

  public Precios?: Array<{
    enlace?: string,
    precio?: number,
  }> = [];

  public Warning?: {
    message?: string,
    code?: number,
  } = {};

  public Error?: {
    message?: string,
    code?: number,
  } = {};

  public Info?: {
    message?: string,
    code?: number,
  } = {};
  ListaPrecios: any;

  constructor(
    public myapp: AppComponent,
    public router: Router,
    private dataService: DataService,
    private todosEnlacesService: todosEnlacesService
  ) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
    const sourcePageAction: string = this.dataService.getSource();
    const args: any[] = this.dataService.getArgs();
    if (sourcePageAction) {
      try {
        if (args) {
          const body: object = this.dataService.getBody();
          Object.values(body).forEach(({ destination, value }) => {
            const fieldName = R.head(destination);
            const nestedFieldNames = R.tail(destination);
            this[fieldName] = R.assocPath(nestedFieldNames)(value)(this[fieldName]);
          });
        }
        this[sourcePageAction].apply(this, args || []);
      } catch (err) { }
    }
    this.autor=sessionStorage.getItem("autor");
    this.titulo=sessionStorage.getItem("titulo");
    this.esconderBotones();
    this.cargarEnlaces(this.titulo, this.autor);
  }


  esconderBotones() {
    document.getElementById("btnInicio").hidden = false;
    if (sessionStorage.getItem("Iniciado")) {
      document.getElementById("btnIniciarSesion").hidden = true;
      document.getElementById("btnRegistrarse").hidden = true;
      document.getElementById("cerrarSesion").hidden = false;
    } else {
      document.getElementById("cerrarSesion").hidden = true;
      document.getElementById("btnIniciarSesion").hidden = false;
      document.getElementById("btnRegistrarse").hidden = false;
    }

  }

  cargarEnlaces(
    titulo: string,
    autor: string
  ) {
    console.log("Obteniendo todos los enlaces con cada precio para el libro con el título: "+titulo+" del autor: "+autor);
    this.todosEnlacesService.obtenerEnlaces(titulo, autor).subscribe(
      ok => {
        console.log(ok);
        this.Precios = ok.body.libros;
      },
      error => {
        this.Error2();
      }
    );
  }

  Error2() {
    alert("No se ha encontrado el libro");


    this.router.navigate(['menuPrincipal']);
  }




  showWarning(message: string, code: number) {
    this.Warning.message = message;
    this.Warning.code = code;
  }

  showError(message: string, code: number) {
    this.Error.message = message;
    this.Error.code = code;
  }

  showInfo(message: string, code: number) {
    this.Info.message = message;
    this.Info.code = code;
  }

}
