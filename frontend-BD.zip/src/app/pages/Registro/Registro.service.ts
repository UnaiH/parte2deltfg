import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Usuario } from '../domain/Usuario/Usuario';


@Injectable({
  providedIn: 'root'
})
export class RegistroService {


  constructor(private http: HttpClient) { }

  registrarse(contrasena: any, usu: any): Observable<any> {
    console.log(contrasena + " , " + usu);
    const data: string = JSON.stringify({
      usuarioReg: new Usuario(usu,contrasena)
    }, (k, v) => v === undefined ? null : v
    );
    const httpOptions = {
      observe: 'body',
    };
    return this.http.get<any>(
      `${environment.backUrl}/usuarios/registroUsuarios?nombreUsuario=${usu}&contrasena=${contrasena}`
      , { ...httpOptions, observe: 'response' }
    );
  }


}
