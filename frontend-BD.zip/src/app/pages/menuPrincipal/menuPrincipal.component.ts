import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from 'src/app/data.service';
import { isNil, isNotNil } from 'src/app/shared/utils/utils';
import { BaseComponent } from 'src/app/shared/base.component';
import * as R from 'ramda';

import { menuPrincipalService } from './menuPrincipal.service';
import { AppComponent } from 'src/app/app.component';

@Component({
  selector: 'app-menuprincipal',
  templateUrl: './menuPrincipal.component.html',
  styleUrls: ['./menuPrincipal.component.css']
})
export class menuPrincipalComponent extends BaseComponent implements OnInit {

  readonly PAGE_NAME = 'menuPrincipal';
  public isNil = isNil;
  public isNotNil = isNotNil;

  public nombreAutor?: string;

  public apellidosAutor?: string;

  public titulo?: string;

  public autor?: string;

  public Warning?: {
    message?: string,
    code?: number,
  } = {};

  public Error?: {
    message?: string,
    code?: number,
  } = {};

  public Info?: {
    message?: string,
    code?: number,
  } = {};

  public usuarioEliminar?: string;

  constructor(
    public myapp: AppComponent,
    public router: Router,
    private dataService: DataService,
    private menuPrincipalService: menuPrincipalService
  ) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
    const sourcePageAction: string = this.dataService.getSource();
    const args: any[] = this.dataService.getArgs();
    if (sourcePageAction) {
      try {
        if (args) {
          const body: object = this.dataService.getBody();
          Object.values(body).forEach(({ destination, value }) => {
            const fieldName = R.head(destination);
            const nestedFieldNames = R.tail(destination);
            this[fieldName] = R.assocPath(nestedFieldNames)(value)(this[fieldName]);
          });
        }
        this[sourcePageAction].apply(this, args || []);
      } catch (err) { }
    }
  }
  ngAfterViewInit() {
    if(sessionStorage.getItem('borrarUsuario')=="true"){
      this.borrarUsuario();
    }
    this.esconderBotones();
  }

  escribirResena(titulo: string, nombreAutor: string, apellidosAutor: string) {
    console.log("Abriendo ventana para escribir reseña");
    if(nombreAutor!=null && nombreAutor!="" && apellidosAutor!=null && apellidosAutor!="" && titulo!=null && titulo!=""){
      var autor = this.nombreAutor + " " + apellidosAutor;
      const NFmenuPrincipalescribirResenaescribirResena: any = {
        titulo: titulo,
        autor: autor
      };

      this.dataService.setData(
        this.PAGE_NAME + '_escribirResena_NFmenuPrincipalescribirResenaescribirResena',
        NFmenuPrincipalescribirResenaescribirResena,
        null
      );
      this.router.navigate(['escribirResena']);
    }else{
      alert("Rellene los campos de título, nombre del autor y apellidos del autor");
    }
  }

  borrarUsuario() {
    if (sessionStorage.getItem("admin") == "true") {
      sessionStorage.removeItem("admin");
    }
    if (sessionStorage.getItem("admin") == "true") {
      sessionStorage.removeItem("admin");
    }
    alert("Error al realizar el registro o iniciar sesión")
    sessionStorage.removeItem('usuario');
    sessionStorage.removeItem('borrarUsuario');
  }

  verPrecio(nombreAutor: string, apellidosAutor: string ,titulo: string) {
    console.log("Buscando el precio más bajo");
    if(nombreAutor!=null && nombreAutor!="" && apellidosAutor!=null && apellidosAutor!="" && titulo!=null && titulo!=""){
      var autor = nombreAutor + " " + apellidosAutor;
      sessionStorage.setItem("autor", autor);
      sessionStorage.setItem("titulo", titulo);
      const NFmenuPrincipalVerPrecioverPrecio: any = {
        autor: autor,
        titulo: titulo
      };
      this.dataService.setData(
        this.PAGE_NAME + '_verPrecio_NFmenuPrincipalVerPrecioverPrecio',
        NFmenuPrincipalVerPrecioverPrecio,
        null
      );
      this.router.navigate(['VerPrecio']);
    }else{
      alert("Rellene los campos de título, nombre del autor y apellidos del autor");
    }
  }

  esconderBotones() {
    document.getElementById("btnInicio").hidden = true;
    document.getElementById("btnRegistrarse").hidden = true;
    if (sessionStorage.getItem("admin") != "true") {
      document.getElementById("btnVerTodasResenas").hidden = true;
      document.getElementById("usuarioEliminar").hidden = true;
      document.getElementById("btnEliminarUsuario").hidden = true;
    }
    if (sessionStorage.getItem("usuario") == null || sessionStorage.getItem("usuario") == "") {
      document.getElementById("btnEscribirResena").hidden = true;
    }
    if (sessionStorage.getItem("Iniciado")=="true") {
      document.getElementById("btnIniciarSesion").hidden = true;
      document.getElementById("cerrarSesion").hidden = false;
    } else {
      document.getElementById("cerrarSesion").hidden = true;
      document.getElementById("btnIniciarSesion").hidden = false;
    }

  }

  verTodosEnlaces(nombreAutor: string, apellidosAutor: string ,titulo: string) {
    console.log("Buscando todos los enlaces para adquirir el libro con título: "+titulo+" y autor con nombre "+nombreAutor+" y apellidos "+apellidosAutor);
    if(nombreAutor!=null && nombreAutor!="" && apellidosAutor!=null && apellidosAutor!="" && titulo!=null && titulo!=""){
      var autor = nombreAutor + " " + apellidosAutor;
      sessionStorage.setItem("autor", autor);
      sessionStorage.setItem("titulo", titulo);
      const NFmenuPrincipaltodosEnlacesverTodosEnlaces: any = {
        autor: autor,
        titulo: titulo
      };

      this.dataService.setData(
        this.PAGE_NAME + '_verTodosEnlaces_NFmenuPrincipaltodosEnlacesverTodosEnlaces',
        NFmenuPrincipaltodosEnlacesverTodosEnlaces,
        null
      );
      this.router.navigate(['todosEnlaces']);
    }else{
      alert("Rellene los campos de título, nombre del autor y apellidos del autor");
    }
  }

  VerResena(nombreAutor: string, apellidosAutor: string ,titulo: string) {
    var autor = nombreAutor + " " + apellidosAutor
    console.log("Buscando las reseñas del libro con título: "+titulo+" y autor: "+autor);
    if(nombreAutor!=null && nombreAutor!="" && apellidosAutor!=null && apellidosAutor!="" && titulo!=null && titulo!=""){
      const NFmenuPrincipalVerResenasVerResena: any = {
        autor: autor,
        titulo: titulo
      };
      this.dataService.setData(
        this.PAGE_NAME + '_VerResena_NFmenuPrincipalVerResenasVerResena',
        NFmenuPrincipalVerResenasVerResena,
        null
      );
      this.router.navigate(['VerResenas']);
    }else{
      alert("Rellene los campos de título, nombre del autor y apellidos del autor");
    }
  }

  VerTodasResenas() {
    console.log("Buscando todas las reseñas ordenadas por usuario");
    this.router.navigate(['TodasResenas']);
  }

  eliminarUsuario(
    usuarioEliminar: string
  ) {
    console.log("Intentando eliminar el usuario: "+usuarioEliminar);
    document.getElementById("usuarioEliminar").innerHTML ="";
    if(usuarioEliminar!=null && usuarioEliminar!=""){
      this.menuPrincipalService.eliminarUsuario(usuarioEliminar).subscribe(
        ok => {
          alert("El usuario " + usuarioEliminar + " ha sido eliminado correctamente");
        },
        error => {
          this.usuarioEliminar = usuarioEliminar;
          alert("Error al eliminar el usuario: "+usuarioEliminar);
        }
      );
    }else{
      alert("Rellene el campo del usuario a eliminar");
    }
  }

















  showWarning(message: string, code: number) {
    this.Warning.message = message;
    this.Warning.code = code;
  }

  showError(message: string, code: number) {
    this.Error.message = message;
    this.Error.code = code;
  }

  showInfo(message: string, code: number) {
    this.Info.message = message;
    this.Info.code = code;
  }

}
