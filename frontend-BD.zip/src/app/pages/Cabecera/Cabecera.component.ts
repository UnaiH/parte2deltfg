import { Component, OnInit, DoCheck } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from 'src/app/data.service';
import { isNil, isNotNil } from 'src/app/shared/utils/utils';
import { BaseComponent } from 'src/app/shared/base.component';
import * as R from 'ramda';

import { CabeceraService } from './Cabecera.service';
import { AppComponent } from 'src/app/app.component';

@Component({
  selector: 'app-cabecera',
  templateUrl: './Cabecera.component.html',
  styleUrls: ['./Cabecera.component.css']
})
export class CabeceraComponent extends BaseComponent implements OnInit, DoCheck {

  readonly PAGE_NAME = 'Cabecera';
  public isNil = isNil;
  public isNotNil = isNotNil;

  public Warning?: {
    message?: string,
    code?: number,
  } = {};

  public Error?: {
    message?: string,
    code?: number,
  } = {};

  public Info?: {
    message?: string,
    code?: number,
  } = {};

  constructor(
    public myapp: AppComponent,
    public router: Router,
    private dataService: DataService,
    private CabeceraService: CabeceraService
  ) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
  }
  ngAfterViewInit() {
    this.esconderBotones();
  }
  ngDoCheck() {
  }

  esconderBotones() {
    document.body.style.backgroundColor = "dark blue";
    if (sessionStorage.getItem("Iniciado")) {
      document.getElementById("btnIniciarSesion").hidden = true;
      document.getElementById("btnRegistrarse").hidden = true;
      document.getElementById("cerrarSesion").hidden = false;
    } else {
      document.getElementById("cerrarSesion").hidden = true;
      document.getElementById("btnIniciarSesion").hidden = false;
      document.getElementById("btnRegistrarse").hidden = false;
    }

  }

  Inicio() {
    console.log("Volviendo al menú de inicio");
    this.router.navigate(['menuPrincipal']);
  }

  iniciarSesion() {
    console.log("Abriendo pantalla de inicio de sesión");
    this.router.navigate(['inicioSesion']);
  }

  registrarse() {
    console.log("Abriendo pantalla de registro");
    this.router.navigate(['Registro']);
  }

  cerrarSesion() {
    console.log("Cerrando la sesión actual");
    sessionStorage.removeItem('admin');
    sessionStorage.removeItem('usuario');
    sessionStorage.removeItem('Iniciado');
    window.location.reload()
  }

  showWarning(message: string, code: number) {
    this.Warning.message = message;
    this.Warning.code = code;
  }

  showError(message: string, code: number) {
    this.Error.message = message;
    this.Error.code = code;
  }

  showInfo(message: string, code: number) {
    this.Info.message = message;
    this.Info.code = code;
  }

}
