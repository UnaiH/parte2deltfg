import { LibroAuxiliar } from './LibroAuxiliar';

export class ListaLibros {
  libros?: LibroAuxiliar[];
}
