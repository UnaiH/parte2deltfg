import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Resena } from './Resena';

@Injectable({
  providedIn: 'root'
})
export class ResenaService {

  public ResenaBackUrl: string = environment.backUrl + '/' + 'Resena';


  constructor(private http: HttpClient) {
  }

  // Fetch all objects Resena
  getObjectsResena(): Observable<Resena[]> {
    return this.http.get<Resena[]>(
      this.ResenaBackUrl + 's'
    );
  }

  getObjectsResenaPag(
    page: number,
    size: number
  ): Observable<HttpResponse<any>> {
    return this.http.get<HttpResponse<any>>(
      this.ResenaBackUrl + 's/' + page + '/' + size,
      { observe: 'response' }
    );
  }

  // Fetch objects Resena by id without relationships
  getObjectsResenaWithoutRelationships(): Observable<Resena[]> {
    return this.http.get<Resena[]>(
      this.ResenaBackUrl + '/ResenasWithOutRelationships'
    );
  }

  getObjectsResenaWithoutRelationshipsPag(
    page: number,
    size: number
  ): Observable<HttpResponse<any>> {
    return this.http.get<HttpResponse<any>>(
      `${this.ResenaBackUrl}sWithoutRelationships/${page + 1}/${size}`,
      { observe: 'response' }
    );
  }

  // Create object Resena
  createObjectResena(
    objectResena: Resena
  ): Observable<Resena> {
    return this.http.post(
      this.ResenaBackUrl,
      objectResena
    );
  }

  // Fetch object Resena by id
  getObjectResenaById(
    id: string
  ): Observable<Resena> {
    return this.http.get<Resena>(
      this.ResenaBackUrl + '/' + id
    );
  }

  // Fetch object Resena by id without relationships
  getObjectResenaWithoutRelationships(
    id: string
  ): Observable<Resena> {
    return this.http.get<Resena>(
      this.ResenaBackUrl + 'WithoutRelationships' + '/' + id
    );
  }

  // Update object Resena
  updateObjectResena(
    objectResena: Resena
  ): Observable<Resena> {
    return this.http.put<Resena>(
      this.ResenaBackUrl + '/' + objectResena.autor,
      objectResena
    );
  }

  // Delete object Resena
  deleteObjectResena(
    id: string
  ): Observable<Resena> {
    return this.http.delete(
      this.ResenaBackUrl + '/' + id
    );
  }

}
