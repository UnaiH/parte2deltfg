import { Libro } from './../Libro/Libro';
import { Usuario } from './../Usuario/Usuario';

export class Resena {
  constructor(
    public autor?: string,
    public texto?: string,
    public titulo?: Libro,
    public nombreUsuario?: Usuario,
  ) { }
}
