import { Usuario } from './Usuario';
import { Libro } from './Libro';
import { DedaButtonComponent } from 'src/app/components/deda-button/deda-button.component';

export class Resena {
  titulo?: string;
  autor?: string;
  usuario?: string;
  texto?: string;
  accion?: string;
  resenasUsuario?: Usuario[];
  resenasLibro?: Libro[];
}
