import { ResAux } from './ResAux';

export class ListaResenasAux {
  resenas?: ResAux[];
}
