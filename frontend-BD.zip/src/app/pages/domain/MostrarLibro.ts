
export class MostrarLibro {
  precio?: number;
  enlace?: string;
}
