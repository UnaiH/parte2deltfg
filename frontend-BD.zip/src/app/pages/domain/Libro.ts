
export class Libro {
  titulo?: string;
  autor?: string;
}
