
export class LibroAuxiliar {
  precio?: string;
  enlace?: number;
}
