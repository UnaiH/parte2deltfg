import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class TodasResenasService {


  constructor(private http: HttpClient) { }

  eliminarResena(titulo: any, autor: any, usuario: any): Observable<any> {
    console.log("Pasa")
    const data: string = JSON.stringify({
      autor: autor,
      titulo: titulo,
      usuario: usuario
    }, (k, v) => v === undefined ? null : v
    );
    const httpOptions = {
      observe: 'body',
    };
    return this.http.get<any>(
      `${environment.backUrl}/resenas/eliminarResena?titulo=${titulo}&autor=${autor}&usuario=${usuario}`
      , { ...httpOptions, observe: 'response' }
    );
  }
  obtenerTodasResenas(): Observable<any> {
    const httpOptions = {
      observe: 'body',
    };
    return this.http.get<any>(
      `${environment.backUrl}/resenas/obtenerTodasResenas`
      , { ...httpOptions, observe: 'response' }
    );
  }

}
