package com.becdedalow.ms.resenas;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@Slf4j
@SpringBootApplication(scanBasePackages = { "com.becdedalow.ms.resenas" })
@EntityScan(basePackages = { "com.becdedalow.ms.resenas" })
@EnableDiscoveryClient
@EnableFeignClients
public class ResenasApp {
  public static void main(String[] args) {
    log.info("Starting microservice: Resenas");
    System.out.println("Llamada al microservicio 'Reseñas' recibidas exitosamente");
    SpringApplication.run(ResenasApp.class);
  }
}
