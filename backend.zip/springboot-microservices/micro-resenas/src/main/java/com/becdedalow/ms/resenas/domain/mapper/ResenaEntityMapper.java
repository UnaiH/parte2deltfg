package com.becdedalow.ms.resenas.domain.mapper;

import com.becdedalow.ms.resenas.domain.entity.ResenaEntity;
import com.becdedalow.ms.resenas.domain.model.ListaResenas;
import com.becdedalow.ms.resenas.domain.model.Resena;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ResenaEntityMapper {
  @Mapping(target = "titulo", source = "id.titulo")
  @Mapping(target = "autor", source = "id.autor")
  @Mapping(target = "nombreUsuario", source = "id.nombreUsuario")
  @Mapping(target = "texto", source = "texto")
  Resena toApiDomain(final ResenaEntity source);

  List<Resena> toApiDomain(final List<ResenaEntity> source);

  @Mapping(source = "titulo", target = "id.titulo")
  @Mapping(source = "autor", target = "id.autor")
  @Mapping(source = "nombreUsuario", target = "id.nombreUsuario")
  @Mapping(source = "texto", target = "texto")
  ResenaEntity fromApiDomain(final Resena source);

  List<ResenaEntity> fromApiDomain(final List<Resena> source);
}
