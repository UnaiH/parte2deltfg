package com.becdedalow.ms.resenas.domain.repository;

import com.becdedalow.ms.resenas.domain.entity.LibroEntity;
import com.becdedalow.ms.resenas.domain.entity.LibroEntityId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface LibroEntityRepository
    extends JpaRepository<LibroEntity, LibroEntityId>, JpaSpecificationExecutor<LibroEntity> {}
