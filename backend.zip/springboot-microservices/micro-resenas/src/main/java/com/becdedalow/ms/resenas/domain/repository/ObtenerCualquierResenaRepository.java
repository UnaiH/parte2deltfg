package com.becdedalow.ms.resenas.domain.repository;

import com.becdedalow.ms.resenas.domain.model.ListaResenas;
import com.becdedalow.ms.resenas.domain.model.Resena;
import com.becdedalow.ms.resenas.domain.model.ListaResenasAux;
import com.becdedalow.ms.resenas.domain.model.ResAux;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class ObtenerCualquierResenaRepository {
  @Qualifier("entityManagerFactory")
  @Autowired
  private EntityManager entityManager;

  private static final String SQL = "Select * FROM resena ORDER BY nombreUsuario";

  public ListaResenas executeQuery() throws Exception {
    System.out.println("Iniciando ejecución");
    System.out.println("Ejecutando consulta " + SQL);
    try {
      entityManager.joinTransaction();
      List<Object[]> results = entityManager.createNativeQuery(SQL).getResultList();
      System.out.println("Finalizada ejecución");
      ListaResenas lista = new ListaResenas();
      lista.setResenas(new ArrayList<>());
      for (Object[] row : results) {
        Resena resAux = new Resena();
        resAux.setTitulo((String) row[0]);
        resAux.setAutor((String) row[1]);
        resAux.setNombreUsuario((String) row[2]);
        resAux.setTexto((String) row[3]);
        lista.getResenas().add(resAux);
      }
      System.out.println(lista.getResenas().size());
      return lista;

    } catch (NoResultException e) {
      return null;
    }
  }

  public ListaResenas executeQuery2(String titulo, String autor) throws Exception {
    String consulta = "Select * FROM resena WHERE titulo = '" + titulo + "' AND autor = '" + autor + "'";
    System.out.println("Iniciando ejecución");
    System.out.println("Ejecutando consulta " + consulta);
    try {
      entityManager.joinTransaction();
      List<Object[]> results = entityManager.createNativeQuery(consulta).getResultList();
      System.out.println("Finalizada ejecución");
      ListaResenas lista = new ListaResenas();
      lista.setResenas(new ArrayList<>());
      for (Object[] row : results) {
        Resena resAux = new Resena();
        resAux.setTitulo((String) row[0]);
        resAux.setAutor((String) row[1]);
        resAux.setNombreUsuario((String) row[2]);
        resAux.setTexto((String) row[3]);
        lista.getResenas().add(resAux);
      }
      System.out.println(lista.getResenas().size());
      return lista;

    } catch (NoResultException e) {
      return null;
    }
  }
}
