package com.becdedalow.ms.resenas.domain.mapper;

import com.becdedalow.ms.resenas.domain.entity.LibroEntity;
import com.becdedalow.ms.resenas.domain.model.Libro;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class LibroEntityMapperTest {
  @Autowired
  LibroEntityMapper mapper;

  @Test
  public void toApiDomainTest() {
    System.out.println("Inicio de prueba");
    LibroEntity entity = new LibroEntity();
    List<LibroEntity> entityList = Arrays.asList(entity);

    Libro domainClass = mapper.toApiDomain(entity);
    List<Libro> domainClassList = mapper.toApiDomain(entityList);

    Assertions.assertNotNull(domainClass);
    Assertions.assertNotNull(domainClassList);
  }

  @Test
  public void fromApiDomainTest() {
    System.out.println("Inicio de prueba");
    Libro domainClass = new Libro();
    List<Libro> domainClassList = Arrays.asList(domainClass);

    LibroEntity entity = mapper.fromApiDomain(domainClass);
    List<LibroEntity> entityList = mapper.fromApiDomain(domainClassList);

    Assertions.assertNotNull(entity);
    Assertions.assertNotNull(entityList);
  }
}
