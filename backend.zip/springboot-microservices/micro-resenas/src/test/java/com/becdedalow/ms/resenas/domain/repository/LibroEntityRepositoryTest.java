package com.becdedalow.ms.resenas.domain.repository;

import com.becdedalow.ms.resenas.domain.entity.LibroEntity;
import com.becdedalow.ms.resenas.domain.entity.LibroEntityId;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class LibroEntityRepositoryTest {
  @Autowired
  LibroEntityRepository libroRepository;

  @Test
  public void repositoryCrudTest() {
    System.out.println("Inicio de prueba");
    LibroEntityId libroId = new LibroEntityId();
    libroId.setTitulo("string");
    libroId.setAutor("string");

    LibroEntity libro = new LibroEntity();
    libro.setId(libroId);

    libroRepository.save(libro);
    LibroEntity response = libroRepository.findById(libroId).orElse(null);
    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getId(), libro.getId());

    libroRepository.delete(libro);

    Assertions.assertNull(libroRepository.findById(libroId).orElse(null));
  }
}
