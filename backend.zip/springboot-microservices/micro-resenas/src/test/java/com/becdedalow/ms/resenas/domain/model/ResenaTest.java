package com.becdedalow.ms.resenas.domain.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

public class ResenaTest {
    @Test
    public void ResenaTest() {
        Resena res1 = new Resena("El señor de los anillos", "J.R.R.Tolkien", "administrador",
                "Libro con un historia interesante y entretenida pero a veces un poco pesado");
        Resena res2 = null;
        assertNotNull(res1);
        assertNull(res2);
        assertEquals(res1.getAutor(), "J.R.R.Tolkien");
        assertEquals(res1.getTitulo(), "El señor de los anillos");
        assertEquals(res1.getNombreUsuario(), "administrador");
        assertEquals(res1.getTexto(), "Libro con un historia interesante y entretenida pero a veces un poco pesado");
        res2 = new Resena(null, null, null, null);
        assertNotNull(res2);
        assertNull(res2.getAutor());
        assertNull(res2.getTitulo());
        assertNull(res2.getNombreUsuario());
        assertNull(res2.getTexto());

    }
}
