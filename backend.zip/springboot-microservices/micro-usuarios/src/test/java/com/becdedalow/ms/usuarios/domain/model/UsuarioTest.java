package com.becdedalow.ms.usuarios.domain.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

public class UsuarioTest {
    @Test
    public void prueba1() {
        Usuario usu = new Usuario("UsuarioPrueba", "UsuarioPrueba");
        assertNotNull(usu);
        assertEquals("UsuarioPrueba", usu.getNombreUsuario());
        assertEquals("UsuarioPrueba", usu.getPassword());
        assertNotEquals("UsuarioPrueb", usu.getNombreUsuario());
        assertNotEquals("UsuarioPruebaa", usu.getPassword());
    }
}
