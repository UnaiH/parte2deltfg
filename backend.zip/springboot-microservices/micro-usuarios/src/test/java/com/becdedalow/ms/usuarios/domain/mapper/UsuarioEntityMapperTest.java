package com.becdedalow.ms.usuarios.domain.mapper;

import com.becdedalow.ms.usuarios.domain.entity.UsuarioEntity;
import com.becdedalow.ms.usuarios.domain.model.Usuario;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class UsuarioEntityMapperTest {
  @Autowired
  UsuarioEntityMapper mapper;

  @Test
  public void toApiDomainTest() {
    System.out.println("Inicio de prueba");
    UsuarioEntity entity = new UsuarioEntity();
    List<UsuarioEntity> entityList = Arrays.asList(entity);

    Usuario domainClass = mapper.toApiDomain(entity);
    List<Usuario> domainClassList = mapper.toApiDomain(entityList);

    Assertions.assertNotNull(domainClass);
    Assertions.assertNotNull(domainClassList);
  }

  @Test
  public void fromApiDomainTest() {
    System.out.println("Inicio de prueba");
    Usuario domainClass = new Usuario();
    List<Usuario> domainClassList = Arrays.asList(domainClass);

    UsuarioEntity entity = mapper.fromApiDomain(domainClass);
    List<UsuarioEntity> entityList = mapper.fromApiDomain(domainClassList);

    Assertions.assertNotNull(entity);
    Assertions.assertNotNull(entityList);
  }
}
