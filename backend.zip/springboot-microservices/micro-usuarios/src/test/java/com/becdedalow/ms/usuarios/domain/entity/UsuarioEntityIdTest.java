package com.becdedalow.ms.usuarios.domain.entity;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

import com.becdedalow.ms.usuarios.domain.model.Usuario;

public class UsuarioEntityIdTest {
  @Test
  public void pruebaUsuarioId() {
    UsuarioEntityId usu = new UsuarioEntityId();
    UsuarioEntityId usu2 = null;
    assertNull(usu2);
    assertNotNull(usu);
    usu.setNombreUsuario("UsuarioPrueba1");
    assertEquals(usu.getNombreUsuario(), "UsuarioPrueba1");
    assertNotEquals(usu, "UsuarioPrueba2");
  }
}
