package com.becdedalow.ms.usuarios.domain.entity;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

import com.becdedalow.ms.usuarios.domain.model.Usuario;

public class UsuarioEntityTest {
  @Test
  public void pruebaSinId() {
    UsuarioEntity usu = new UsuarioEntity();
    assertNotNull(usu);
    assertNull(usu.getPassword());
    usu.setPassword("UsuarioPrueba1*");
    assertEquals(usu.getPassword(), "UsuarioPrueba1*");
    assertNull(usu.getId());
  }

  @Test
  public void pruebaId() {
    UsuarioEntity usu = new UsuarioEntity();
    UsuarioEntityId usuId = new UsuarioEntityId();
    assertNull(usu.getId());
    assertNull(usuId.getNombreUsuario());
    usuId.setNombreUsuario("UsuarioPrueba1");
    assertEquals(usuId.getNombreUsuario(), "UsuarioPrueba1");
    usu.setId(usuId);
    assertNotNull(usu.getId());
    assertEquals(usu.getId().getNombreUsuario(), "UsuarioPrueba1");
  }

  @Test
  public void pruebaUsuario() {
    UsuarioEntity usu = new UsuarioEntity();
    assertNotNull(usu);
    usu.setPassword("UsuarioPrueba1*");
    assertEquals(usu.getPassword(), "UsuarioPrueba1*");
    UsuarioEntityId usuId = new UsuarioEntityId();
    assertNull(usu.getId());
    assertNull(usuId.getNombreUsuario());
    usuId.setNombreUsuario("UsuarioPrueba1");
    assertEquals(usuId.getNombreUsuario(), "UsuarioPrueba1");
    usu.setId(usuId);
    assertNotNull(usu.getId());
    assertEquals(usu.getId().getNombreUsuario(), "UsuarioPrueba1");
  }
}