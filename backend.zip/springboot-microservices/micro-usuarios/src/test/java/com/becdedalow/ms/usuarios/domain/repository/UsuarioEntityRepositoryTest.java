package com.becdedalow.ms.usuarios.domain.repository;

import com.becdedalow.ms.usuarios.domain.entity.UsuarioEntity;
import com.becdedalow.ms.usuarios.domain.entity.UsuarioEntityId;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class UsuarioEntityRepositoryTest {
  @Autowired
  UsuarioEntityRepository usuarioRepository;

  @Test
  public void repositoryCrudTest() {
    System.out.println("Inicio de prueba");
    UsuarioEntityId usuarioId = new UsuarioEntityId();
    usuarioId.setNombreUsuario("CreandoUsu");

    UsuarioEntity usuario = new UsuarioEntity();
    usuario.setPassword("CreandoUsu");
    usuario.setId(usuarioId);

    usuarioRepository.save(usuario);
    UsuarioEntity response = usuarioRepository.findById(usuarioId).orElse(null);
    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getId(), usuario.getId());

    usuarioRepository.delete(usuario);

    Assertions.assertNull(usuarioRepository.findById(usuarioId).orElse(null));
  }
}
