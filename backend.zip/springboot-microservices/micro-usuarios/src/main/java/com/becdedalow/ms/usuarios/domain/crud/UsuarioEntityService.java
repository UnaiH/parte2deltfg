package com.becdedalow.ms.usuarios.domain.crud;

import com.becdedalow.ms.usuarios.domain.entity.UsuarioEntity;
import com.becdedalow.ms.usuarios.domain.entity.UsuarioEntityId;
import com.becdedalow.ms.usuarios.domain.mapper.UsuarioEntityMapper;
import com.becdedalow.ms.usuarios.domain.model.Usuario;
import com.becdedalow.ms.usuarios.domain.repository.UsuarioEntityRepository;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UsuarioEntityService {
  @Autowired
  private final UsuarioEntityRepository repository;

  @Autowired
  private final UsuarioEntityMapper mapper;

  public Usuario findById(String usuario) throws Exception {
    System.out.println("Iniciando búsqueda del usuario: " + usuario);
    UsuarioEntityId requestId = new UsuarioEntityId();

    requestId.setNombreUsuario(usuario);

    System.out.println("ID a buscar: " + requestId.getNombreUsuario());
    Optional<UsuarioEntity> response = repository.findById(requestId);

    System.out.println("Finalizado el proceso de búsqueda del usuario en la base de datos");

    return (response.isPresent()) ? mapper.toApiDomain(response.get()) : null;
  }

  public Usuario create(Usuario usuario) throws Exception {
    System.out.println("Iniciando proceso de registro de usuario en la base de datos");
    return mapper.toApiDomain(repository.save(mapper.fromApiDomain(usuario)));
  }

  public void remove(String usuario) throws Exception {

    System.out.println("Iniciando el proceso de eliminación del usuario en la base de datos");
    UsuarioEntityId requestId = new UsuarioEntityId();

    requestId.setNombreUsuario(usuario);

    repository.deleteById(requestId);
    System.out.println("Finalizado el proceso de eliminación del usuario en la base de datos");
  }
}
