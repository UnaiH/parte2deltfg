package com.becdedalow.ms.precios.controller;

import com.becdedalow.ms.precios.domain.model.LibroAuxiliar;
import com.becdedalow.ms.precios.domain.model.ListaLibros;
import com.becdedalow.ms.precios.service.PreciosService;
import java.math.BigDecimal;
import java.util.Arrays;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@SpringBootTest
public class PreciosControllerTest {
        @Autowired
        private PreciosController preciosController;

        @MockBean
        private PreciosService preciosService;

        @Test
        public void obtenerEnlacesTest() throws Exception {
                System.out.println("Inicio de prueba 1");
                ListaLibros mockedResponse = ListaLibros.builder().libros(
                                Arrays.asList(LibroAuxiliar.builder().precio("1.20").enlace("https://www.google.com")
                                                .build()))
                                .build();

                Mockito.when(
                                preciosService.obtenerEnlaces("El ingenioso hidalgo don Quijote de la Mancha", "Miguel",
                                                "de Cervantes"))
                                .thenReturn(mockedResponse);

                ResponseEntity<ListaLibros> response = preciosController
                                .obtenerEnlaces("El ingenioso hidalgo don Quijote de la Mancha", "Miguel de Cervantes");

                Assertions.assertNotNull(response);
                Assertions.assertTrue(response.hasBody());
                Assertions.assertEquals(response.getBody(), mockedResponse);
        }

        @Test
        public void obtenerEnlacesExceptionTest() throws Exception {
                System.out.println("Inicio de prueba");
                Mockito.when(
                                preciosService.obtenerEnlaces(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class)))
                                .thenThrow(new Exception());

                ResponseEntity<ListaLibros> response = preciosController
                                .obtenerEnlaces("El ingenioso hidalgo don Quijote de la Mancha", "Miguel de Cervantes");

                Assertions.assertNotNull(response);
                Assertions.assertEquals(response.getStatusCode(), HttpStatus.NOT_FOUND);
                System.out.println("Fin de prueba");
        }

        @Test
        public void obtenerEnlacesNotFoundTest() throws Exception {
                System.out.println("Inicio de prueba");
                ListaLibros mockedResponse = null;

                Mockito.when(
                                preciosService.obtenerEnlaces(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class)))
                                .thenReturn(mockedResponse);

                ResponseEntity<ListaLibros> response = preciosController
                                .obtenerEnlaces("El ingenioso hidalgo don Quijote de la Mancha", "Miguel de Cervantes");

                Assertions.assertNotNull(response);
                Assertions.assertEquals(response.getStatusCode(), HttpStatus.NOT_FOUND);
        }

        @Test
        public void obtenerEnlacesNullParamsTest() throws Exception {
                System.out.println("Inicio de prueba");
                ListaLibros mockedResponse = ListaLibros.builder()
                                .libros(
                                                Arrays.asList(
                                                                LibroAuxiliar.builder().precio("string")
                                                                                .enlace("string").build()))
                                .build();

                Mockito.when(
                                preciosService.obtenerEnlaces(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class)))
                                .thenReturn(mockedResponse);

                ResponseEntity<ListaLibros> response = preciosController.obtenerEnlaces(null, null);

                Assertions.assertNotNull(response);
                Assertions.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
        }

        @Test
        public void mejorPrecioTest() throws Exception {
                System.out.println("Inicio de prueba");
                LibroAuxiliar mockedResponse = LibroAuxiliar.builder().precio("string").enlace("string").build();

                Mockito.when(
                                preciosService.mejorPrecio("El ingenioso hidalgo don Quijote de la Mancha", "Miguel",
                                                "de Cervantes"))
                                .thenReturn(mockedResponse);

                ResponseEntity<LibroAuxiliar> response = preciosController
                                .mejorPrecio("El ingenioso hidalgo don Quijote de la Mancha", "Miguel de Cervantes");

                Assertions.assertNotNull(response);
                Assertions.assertTrue(response.hasBody());
                Assertions.assertEquals(response.getBody(), mockedResponse);
        }

        @Test
        public void mejorPrecioExceptionTest() throws Exception {
                System.out.println("Inicio de prueba2");
                Mockito.when(
                                preciosService.mejorPrecio(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class)))
                                .thenThrow(new Exception());

                ResponseEntity<LibroAuxiliar> response = preciosController
                                .mejorPrecio("El ingenioso hidalgo don Quijote de la Mancha", "Miguel de Cervantes");

                Assertions.assertNotNull(response);
                Assertions.assertEquals(response.getStatusCode(), HttpStatus.NOT_FOUND);
        }

        @Test
        public void mejorPrecioNotFoundTest() throws Exception {
                System.out.println("Inicio de prueba");
                LibroAuxiliar mockedResponse = null;

                Mockito.when(
                                preciosService.mejorPrecio(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class)))
                                .thenReturn(mockedResponse);

                ResponseEntity<LibroAuxiliar> response = preciosController
                                .mejorPrecio("El ingenioso hidalgo don Quijote de la Mancha", "Miguel de Cervantes");

                Assertions.assertNotNull(response);
                Assertions.assertEquals(response.getStatusCode(), HttpStatus.NOT_FOUND);
        }

        @Test
        public void mejorPrecioNullParamsTest() throws Exception {
                System.out.println("Inicio de prueba");
                LibroAuxiliar mockedResponse = LibroAuxiliar.builder().precio("string").enlace("string").build();

                Mockito.when(
                                preciosService.mejorPrecio(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class)))
                                .thenReturn(mockedResponse);

                ResponseEntity<LibroAuxiliar> response = preciosController.mejorPrecio(null, null);

                Assertions.assertNotNull(response);
                Assertions.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
        }
}
