package com.becdedalow.ms.precios.logic;

import com.becdedalow.ms.precios.domain.model.LibroAuxiliar;
import com.becdedalow.ms.precios.domain.model.ListaLibros;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class FiltradoServiceTest {
  @Autowired
  private FiltradoService filtradoService;

  @Test
  public void comparacionFiltradoTest() throws Exception {
    System.out.println("Inicio de prueba");

    Assertions.assertNull(null);
  }

  @Test
  public void filtrarTest() throws Exception {
    System.out.println("Inicio de prueba");

    Assertions.assertNull(null);
  }
}
