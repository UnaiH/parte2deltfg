package com.becdedalow.ms.precios.service;

import com.becdedalow.ms.precios.domain.model.LibroAuxiliar;
import com.becdedalow.ms.precios.domain.model.ListaLibros;
import com.becdedalow.ms.precios.logic.FiltradoService;
import com.becdedalow.ms.precios.rest.RestRepository;
import org.jeasy.random.EasyRandom;
import org.jeasy.random.EasyRandomParameters;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class PreciosServiceTest {
  @InjectMocks
  @Spy
  private PreciosService preciosService;

  @Mock
  private RestRepository restRepository;

  @Mock
  private FiltradoService filtradoService;

  private EasyRandom generator;

  @BeforeEach
  public void setUp() {
    EasyRandomParameters parameters = new EasyRandomParameters();
    parameters.overrideDefaultInitialization(true);
    generator = new EasyRandom();
  }

  @Test
  public void obtenerEnlacesTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doReturn("string")
        .when(restRepository);
    RestRepository
        .tPrecios("El ingenioso hidalgo don Quijote de la Mancha", "Miguel de Cervantes",
            "AIzaSyBdNYZeVARrXAFO6ZULBgIsUQEteB1qxXg");

    Mockito.when(filtradoService.filtrar(
        Mockito.nullable(String.class),
        Mockito.nullable(String.class),
        Mockito.nullable(String.class))).thenReturn(generator.nextObject(ListaLibros.class));

    Assertions.assertNotNull(preciosService.obtenerEnlaces("string", "string", "string"));
  }

  @Test
  public void obtenerEnlacesObtenerListaExceptionTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doThrow(new Exception())
        .when(restRepository);
    RestRepository
        .tPrecios(Mockito.nullable(String.class), Mockito.nullable(String.class),
            "AIzaSyBdNYZeVARrXAFO6ZULBgIsUQEteB1qxXg");

    Mockito.doReturn(generator.nextObject(ListaLibros.class))
        .when(filtradoService)
        .filtrar(
            Mockito.nullable(String.class),
            Mockito.nullable(String.class),
            Mockito.nullable(String.class));

    preciosService.obtenerEnlaces("string", "string", "string");
  }

  @Test
  public void obtenerEnlacesFiltrarExceptionTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doReturn("string")
        .when(restRepository);
    RestRepository
        .tPrecios(Mockito.nullable(String.class), Mockito.nullable(String.class),
            "AIzaSyBdNYZeVARrXAFO6ZULBgIsUQEteB1qxXg");

    Mockito.doThrow(new Exception())
        .when(filtradoService)
        .filtrar(
            Mockito.nullable(String.class),
            Mockito.nullable(String.class),
            Mockito.nullable(String.class));

    preciosService.obtenerEnlaces("string", "string", "string");
  }

  @Test
  public void mejorPrecioTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doReturn("string")
        .when(restRepository)
        .mPrecios(Mockito.nullable(String.class), Mockito.nullable(String.class),
            "AIzaSyBdNYZeVARrXAFO6ZULBgIsUQEteB1qxXg");

    Mockito.doReturn(generator.nextObject(LibroAuxiliar.class))
        .when(filtradoService)
        .comparacionFiltrado(
            Mockito.nullable(String.class),
            Mockito.nullable(String.class),
            Mockito.nullable(String.class));

    Assertions.assertNotNull(preciosService.mejorPrecio("string", "string", "string"));
  }

  @Test
  public void mejorPrecioObtenerListaExceptionTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doThrow(new Exception())
        .when(restRepository)
        .mPrecios(Mockito.nullable(String.class), Mockito.nullable(String.class),
            "AIzaSyBdNYZeVARrXAFO6ZULBgIsUQEteB1qxXg");

    Mockito.doReturn(generator.nextObject(LibroAuxiliar.class))
        .when(filtradoService)
        .comparacionFiltrado(
            Mockito.nullable(String.class),
            Mockito.nullable(String.class),
            Mockito.nullable(String.class));

    preciosService.mejorPrecio("string", "string", "string");
  }

  @Test
  public void mejorPrecioComparacionFiltradoExceptionTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doReturn("string")
        .when(restRepository)
        .mPrecios(Mockito.nullable(String.class), Mockito.nullable(String.class),
            "AIzaSyBdNYZeVARrXAFO6ZULBgIsUQEteB1qxXg");

    Mockito.doThrow(new Exception())
        .when(filtradoService)
        .comparacionFiltrado(
            Mockito.nullable(String.class),
            Mockito.nullable(String.class),
            Mockito.nullable(String.class));

    preciosService.mejorPrecio("string", "string", "string");
  }
}
