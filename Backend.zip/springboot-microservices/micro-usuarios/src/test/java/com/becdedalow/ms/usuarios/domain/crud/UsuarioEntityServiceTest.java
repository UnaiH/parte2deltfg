package com.becdedalow.ms.usuarios.domain.crud;

import com.becdedalow.ms.usuarios.domain.entity.UsuarioEntity;
import com.becdedalow.ms.usuarios.domain.mapper.UsuarioEntityMapper;
import com.becdedalow.ms.usuarios.domain.model.Usuario;
import com.becdedalow.ms.usuarios.domain.repository.UsuarioEntityRepository;
import java.util.ArrayList;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class UsuarioEntityServiceTest {
  @InjectMocks
  private UsuarioEntityService usuarioService;
  @Mock
  private UsuarioEntityRepository repository;
  @Mock
  private UsuarioEntityMapper mapper;

  @BeforeEach
  public void setUp() {
    System.out.println("Inicio de prueba");
    Mockito.when(mapper.fromApiDomain(Mockito.any(Usuario.class))).thenReturn(new UsuarioEntity());
    Mockito.when(mapper.fromApiDomain(Mockito.anyList()))
        .thenReturn(new ArrayList<UsuarioEntity>());
    Mockito.when(mapper.toApiDomain(Mockito.anyList())).thenReturn(new ArrayList<Usuario>());
    Mockito.when(mapper.toApiDomain(Mockito.any(UsuarioEntity.class))).thenReturn(new Usuario());
  }

  @Test
  public void iniciarSesionTest() throws Exception {
    System.out.println("Inicio de prueba");
    Usuario result = usuarioService.findById("administrador");

    Assertions.assertNotNull(result);
  }

  @Test
  public void registrarseTest() throws Exception {
    System.out.println("Inicio de prueba");
    Usuario result = usuarioService
        .create(Usuario.builder().password("ProbandoTest").nombreUsuario("ProbandoTest").build());

    Assertions.assertNotNull(result);
  }

  @Test
  public void eliminarUsuTest() throws Exception {
    System.out.println("Inicio de prueba");
    usuarioService.remove("string");
  }
}
