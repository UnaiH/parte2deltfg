package com.becdedalow.ms.usuarios.service;

import com.becdedalow.ms.usuarios.domain.crud.UsuarioEntityService;
import com.becdedalow.ms.usuarios.domain.model.Usuario;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class UsuariosService {

  private final UsuarioEntityService usuarioEntityService;

  public void eliminarUsuario(String usuario) throws Exception {

    log.debug("Using method executeEliminarUsuario");
    System.out.println("Usuario recibido para ser eliminado: " + usuario);

    try {

      usuarioEntityService.remove(usuario);
      System.out.println("Proceso de eliminación del usuario finalizado");
    } catch (Exception e) {

      log.error(e.getMessage(), e);
    }
  }

  public void inicioSesion(String usuario, String contrasena) throws Exception {

    log.debug("Using method executeInicioSesion");

    System.out.println("Iniciando proceso de iniciado de sesión del usuario: " + usuario);

    Usuario usu = null;

    try {
      System.out.println("Comenzando el proceso de búsqueda del usuario en la base de datos");
      usu = usuarioEntityService.findById(usuario);
      System.out.println("Finalizado el proceso de búsqueda del usuario: " + usu.getNombreUsuario());
    } catch (Exception e) {

      log.error(e.getMessage(), e);
    }
    if (usu != null) {
      if (usu.getPassword().equals(contrasena)) {
        System.out.println("Se ha logrado iniciar sesión exitosamente");
      } else {
        System.out.println("No se ha podido iniciar sesión con éxito con el usuario: " + usuario);
        throw new Exception("404");
      }
    } else {
      System.out.println("No se ha podido iniciar sesión con éxito con el usuario: " + usuario);
      throw new Exception("404");
    }
  }

  public void registroUsuarios(Usuario usuario) throws Exception {

    log.debug("Using method executeRegistroUsuarios");

    System.out
        .println("iniciando proceso de registro del usuario " + usuario.getNombreUsuario() + " en la base de datos");

    Usuario esUsuario = null;

    Usuario registro = null;

    try {
      System.out.println("Iniciando llamada al método para buscar el usuari en la base de datos");
      esUsuario = usuarioEntityService.findById(usuario.getNombreUsuario());
      System.out.println("Llamada al método realizada exitosamente");
    } catch (Exception e) {

      log.error(e.getMessage(), e);
    }
    if (esUsuario != null) {
      System.out.println("Usuario ya existente en la base de datos devolviendo un error al controller.");
      throw new Exception("UsuarioExistente");
    } else {
      System.out.println("El usuario no existe con anterioridad en la base de datos");
      try {
        System.out.println("Iniciando proceso de creación del nuevo usuario en la base de datos");
        registro = usuarioEntityService.create(usuario);
        System.out.println("Finalizado el proceso de creación del nuevo usuario en la base de datos");
      } catch (Exception e) {
        System.out.println("Error a la hora de registrar el usuario.");
        log.error(e.getMessage(), e);
      }
    }
  }
}
