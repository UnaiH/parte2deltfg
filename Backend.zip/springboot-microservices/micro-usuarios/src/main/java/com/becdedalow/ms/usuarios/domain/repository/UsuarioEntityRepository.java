package com.becdedalow.ms.usuarios.domain.repository;

import com.becdedalow.ms.usuarios.domain.entity.UsuarioEntity;
import com.becdedalow.ms.usuarios.domain.entity.UsuarioEntityId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface UsuarioEntityRepository
        extends JpaRepository<UsuarioEntity, UsuarioEntityId>,
        JpaSpecificationExecutor<UsuarioEntity> {
}
