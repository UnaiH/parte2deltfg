package com.becdedalow.ms.usuarios.domain.mapper;

import com.becdedalow.ms.usuarios.domain.entity.UsuarioEntity;
import com.becdedalow.ms.usuarios.domain.model.Usuario;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface UsuarioEntityMapper {
  @Mapping(target = "nombreUsuario", source = "id.nombreUsuario")
  @Mapping(target = "password", source = "password")
  Usuario toApiDomain(final UsuarioEntity source);

  List<Usuario> toApiDomain(final List<UsuarioEntity> source);

  @Mapping(source = "nombreUsuario", target = "id.nombreUsuario")
  @Mapping(source = "password", target = "password")
  UsuarioEntity fromApiDomain(final Usuario source);

  List<UsuarioEntity> fromApiDomain(final List<Usuario> source);
}
