package com.becdedalow.ms.usuarios.controller;

import com.becdedalow.ms.usuarios.domain.model.Usuario;
import com.becdedalow.ms.usuarios.service.UsuariosService;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.apache.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class UsuariosController {
  private final UsuariosService usuariosService;

  @PostMapping("/eliminarUsuario")
  public ResponseEntity<Void> eliminarUsuario(@RequestParam(name = "nombreUsuario", required = true) String usuario) {
    System.out.println("Iniciando proceso de eliminarUsuario en UsuarioController");
    log.debug(
        "Start of call to UsuariosController - eliminarUsuario with parameters: " + "usuario={}",
        usuario);

    List<String> errorParams = new ArrayList<>();
    if (Objects.isNull(usuario)) {
      errorParams.add("usuario");
    }

    if (!errorParams.isEmpty()) {
      ResponseEntity.status(400);
      return ResponseEntity.badRequest().build();
    }

    try {
      System.out.println("Llamando al método eliminarUsuario de usuariosService");
      usuariosService.eliminarUsuario(usuario);
      System.out.println("Finalizada la llamada al método eliminarUsuario");
    } catch (Exception e) {
      log.error("Exception: {0}", e);
      return ResponseEntity.badRequest().build();
    }

    log.debug("End of call to UsuariosController - eliminarUsuario");

    System.out.println("Finalizado el proceso de eliminar usuario");
    ResponseEntity.status(200);
    return ResponseEntity.ok().build();
  }

  @PostMapping("/inicioSesion")
  public ResponseEntity<Void> inicioSesion(@RequestParam(name = "nombreUsuario", required = true) String usu,
      @RequestParam(name = "contrasena", required = true) String contrasena, HttpServletResponse response) {
    System.out.println("Comenzando proceso de inicio de sesión para el usuario: " + usu);
    log.debug(
        "Start of call to UsuariosController - inicioSesion with parameters: " + "usuario={}" + " - " + "contrasena={}",
        usu);

    List<String> errorParams = new ArrayList<>();
    if (Objects.isNull(usu)) {
      errorParams.add("nombreUsuario");
    }
    if (Objects.isNull(contrasena)) {
      errorParams.add("contrasena");
    }
    if (!errorParams.isEmpty()) {
      System.out.println("Hay errores en los parámetros recibidos");
      return ResponseEntity.badRequest().build();
    }

    try {
      System.out.println("Llamada para iniciar la sesión del usuario comenzado");
      usuariosService.inicioSesion(usu, contrasena);
      System.out.println("Llamada de inicio de sesión finalizada");
    } catch (Exception e) {
      log.error("Exception: {0}", e);
      return ResponseEntity.badRequest().build();
    }

    log.debug("End of call to UsuariosController - inicioSesion");
    System.out.println("Proceso del inicio de sesión de 'UsuarioController' finalizado");
    response.addHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    return ResponseEntity.ok().build();
  }

  @GetMapping("/registroUsuarios")
  public ResponseEntity<Void> registroUsuarios(
      @RequestParam(name = "nombreUsuario", required = true) String nombreUsuario,
      @RequestParam(name = "contrasena", required = true) String contrasena) {

    log.debug("Start of call to UsuariosController - registroUsuarios with parameters: " + "Usuario={}", nombreUsuario);
    System.out
        .println("Iniciando proceso de registro de usuario con el nombre de usuario: " + nombreUsuario);
    List<String> errorParams = new ArrayList<>();
    if (Objects.isNull(nombreUsuario)) {
      errorParams.add("nombreUsuario");
    }
    if (Objects.isNull(contrasena)) {
      errorParams.add("nombreUsuario");
    }

    if (!errorParams.isEmpty()) {
      System.out.println("Error en la recepción de los parámetros");
      return ResponseEntity.badRequest().build();
    }
    Usuario usuario = new Usuario(contrasena, nombreUsuario);
    try {
      System.out.println("Realizando llamada al método registroUsuario");
      usuariosService.registroUsuarios(usuario);
      System.out.println("Finalizada la llamada al método de registroUsuario");

    } catch (Exception e) {
      log.error("Exception: {0}", e);
      return ResponseEntity.badRequest().build();
    }

    log.debug("End of call to UsuariosController - registroUsuarios");
    System.out.println("Proceso del registro de usuario de 'UsuarioController' finalizado");
    return ResponseEntity.ok().build();
  }
}
