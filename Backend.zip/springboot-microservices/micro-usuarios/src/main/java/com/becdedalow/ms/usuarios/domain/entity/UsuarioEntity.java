package com.becdedalow.ms.usuarios.domain.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "Usuario")
public class UsuarioEntity implements Serializable {

  private static final long serialVersionUID = 1L;

  @EmbeddedId
  private UsuarioEntityId id;

  @Column(name = "password")
  private String password;
}
