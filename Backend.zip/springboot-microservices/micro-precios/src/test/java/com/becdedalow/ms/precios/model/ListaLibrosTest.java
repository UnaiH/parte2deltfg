package com.becdedalow.ms.precios.model;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.becdedalow.ms.precios.domain.model.LibroAuxiliar;
import com.becdedalow.ms.precios.domain.model.ListaLibros;

public class ListaLibrosTest {
    @Test
    public void pruebaListaLibros() {
        ListaLibros lista = null;
        assertNull(lista);
        lista = new ListaLibros();
        assertNotNull(lista);

        assertNotNull(lista.getLibros());
        assertFalse(lista.getLibros().size() > 0);
        LibroAuxiliar libro1 = new LibroAuxiliar();
        libro1.setPrecio("0.5");
        libro1.setEnlace("https://www.google.com");
        lista.getLibros().add(libro1);
        assertTrue(lista.getLibros().size() > 0);
    }
}