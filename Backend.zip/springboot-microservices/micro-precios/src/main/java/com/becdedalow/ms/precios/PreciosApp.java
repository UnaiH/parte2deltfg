package com.becdedalow.ms.precios;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@Slf4j
@SpringBootApplication(scanBasePackages = { "com.becdedalow.ms.precios" })
@EntityScan(basePackages = { "com.becdedalow.ms.precios" })
@EnableDiscoveryClient
@EnableFeignClients
public class PreciosApp {
  public static void main(String[] args) {
    System.out.println("Inicializando el microservicio llamado 'Precios'");
    log.info("Starting microservice: Precios");

    SpringApplication.run(PreciosApp.class);
  }
}
