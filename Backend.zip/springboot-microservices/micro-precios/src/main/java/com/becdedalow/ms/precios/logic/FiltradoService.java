package com.becdedalow.ms.precios.logic;

import com.becdedalow.ms.precios.domain.model.LibroAuxiliar;
import com.becdedalow.ms.precios.domain.model.ListaLibros;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class FiltradoService {
  public ListaLibros filtrar(String lista, String titulo, String autor) throws Exception {

    System.out.println("Iniaciando filtrado de la respuesta por el titulo: " + titulo + " y el autor: " + autor);
    ListaLibros listaFiltrada = new ListaLibros();
    titulo = titulo.replace("_", " ");
    autor = autor.replace("_", " ");
    ArrayList<String> listaAuxiliar = new ArrayList<>();
    System.out.println("Iniciando división del string de respuesta de la API");
    for (String libro : lista.split("kind")) {
      if (libro.contains(autor)) {
        listaAuxiliar.add(libro);
      }
    }
    System.out.println("Comenzando proceso de filtrado del resultado de la API");
    if (listaAuxiliar.size() > 0) {
      int i = 0;
      // Se recorre la lista de strings
      while (listaAuxiliar.size() > i) {
        String libAux = listaAuxiliar.get(i);
        // Si contiene el titulo del libro buscado pero no contiene el substring
        // "buyLink" se guarda en una lista con el enlace y el precio "0.00"
        if (libAux.contains(titulo)) {
          if (!libAux.contains("buyLink")) {
            String linkNoOnline = "http:" + libAux.split("infoLink")[1].split(",")[0].split(":")[2].replace("\"", "");
            LibroAuxiliar auxLib = new LibroAuxiliar();
            auxLib.setEnlace(linkNoOnline);
            auxLib.setPrecio("0.00");
            listaFiltrada.getLibros().add(auxLib);
          } else {
            // Si contiene el substring "buylink" se sigue procesando la respuesta para
            // obtener la informacion
            String precios = libAux.split("saleInfo")[1];
            // Si continene el substring "amount" se obtiene el precio y la url de donde
            // comprarlo.
            if (precios.contains("amount")) {
              String link = "https:" + precios.split("buyLink")[1].split(",")[0].split(":")[2].replace("\"", "");
              String[] listaPrecio = precios.split("listPrice");
              int l = 0;
              boolean fin1 = false;
              while (l < listaPrecio.length && !fin1) {
                if (l == 1) {
                  int k = 0;
                  String[] amounts = listaPrecio[1].split("amount");
                  boolean fin2 = false;
                  while (k < amounts.length && !fin2) {
                    if (k == 1) {
                      int j = 0;
                      String[] filtrados = amounts[1].split(",");
                      boolean fin3 = false;
                      while (j < filtrados.length && !fin3) {
                        if (j == 0) {
                          String filtr = filtrados[0].replace("\": ", "");
                          System.out.println(filtr);
                          LibroAuxiliar auxLib = new LibroAuxiliar();
                          auxLib.setEnlace(link);
                          auxLib.setPrecio("" + Double.parseDouble(filtr));
                          listaFiltrada.getLibros().add(auxLib);
                          fin3 = true;
                        }
                        j++;
                      }
                      System.out.println("Pasa " + k + l + i);
                      fin2 = true;
                    }
                    k++;
                  }
                  fin1 = true;
                }
                l++;
              }
            } else {
              String linkFree = "http:" + libAux.split("buyLink")[1].split("}")[0].split(":")[2].replace("\"", "");
              LibroAuxiliar auxLib = new LibroAuxiliar();
              auxLib.setEnlace(linkFree);
              auxLib.setPrecio("0.00");
              listaFiltrada.getLibros().add(auxLib);
            }
          }
        }
        i++;
      }
    } else {
      System.out.println("La API no ha devulto ningún dato");
      LibroAuxiliar libVacio = new LibroAuxiliar("0.00", "#");
      ListaLibros listaVacia = new ListaLibros();
      listaVacia.getLibros().add(libVacio);
      System.out.println("Finalizada la ejecución de filtrar");
      return listaVacia;
    }
    if (listaFiltrada.getLibros().size() < 1) {
      System.out.println("No se ha logrado ningún dato válido");
      LibroAuxiliar libVacio = new LibroAuxiliar("0.00", "#");
      ListaLibros listaVacia = new ListaLibros();
      listaVacia.getLibros().add(libVacio);
      System.out.println("Finalizada la ejecución de filtrar");
      return listaVacia;
    }
    System.out.println("Finalizada la ejecución de filtrar");
    return listaFiltrada;
  }

  public LibroAuxiliar comparacionFiltrado(String autor, String titulo, String lista) throws Exception {

    System.out.println("Iniciando la ejecución de la comparación y el filtrado de la respuesta de la llamada a la API");
    Double precioMin = Double.POSITIVE_INFINITY;
    String enlaceMin = "";
    String precioAux = "";
    titulo = titulo.replace("_", " ");
    autor = autor.replace("_", " ");
    System.out.println("Llamando al método filtrar()");
    ListaLibros listaAux = this.filtrar(lista, titulo, autor);
    System.out
        .println("Respuesta recibida desde filtrar con " + listaAux.getLibros().size() + " elementos en la lista");
    System.out.println(listaAux.getLibros().toString());
    if (listaAux.getLibros().size() >= 1) {
      if (listaAux.getLibros().size() > 1
          || (listaAux.getLibros().size() == 1 && !listaAux.getLibros().get(0).getEnlace().equals("#"))) {
        System.out.println("Comenzando proceso de búsqueda del libro con el precio menor");
        for (LibroAuxiliar libro : listaAux.getLibros()) {
          precioAux = libro.getPrecio();
          precioAux = precioAux.replace(",", ".");
          if (precioMin > Double.parseDouble(precioAux) && (Double.parseDouble(precioAux) != 0.00)
              && (Double.parseDouble(precioAux) != 0.0) && (Double.parseDouble(precioAux) != 0)) {
            precioMin = Double.parseDouble(precioAux);
            enlaceMin = libro.getEnlace();
          }
        }
      }
    }
    System.out.println("Búsqueda finalizada");
    if (precioMin == Double.POSITIVE_INFINITY) {
      System.out.println("Enlace con un precio asociado no se ha encontrado satisfactoriamente");
      precioMin = 0.00;
      enlaceMin = "#";
    }
    System.out.println(
        "Proceso de filtrado y comparación finalizado. Precio obtenido: " + precioMin + " y enlace: " + enlaceMin);
    return LibroAuxiliar.builder().precio(precioMin.toString()).enlace(enlaceMin).build();
  }
}
