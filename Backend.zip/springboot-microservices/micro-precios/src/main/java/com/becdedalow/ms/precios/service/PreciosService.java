
package com.becdedalow.ms.precios.service;

import com.becdedalow.ms.precios.domain.model.LibroAuxiliar;
import com.becdedalow.ms.precios.domain.model.ListaLibros;
import com.becdedalow.ms.precios.logic.FiltradoService;
import com.becdedalow.ms.precios.rest.RestRepository;

import java.math.BigDecimal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;

import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class PreciosService {

	private final RestRepository restRepository;
	private final FiltradoService filtradoService;

	public ListaLibros obtenerEnlaces(String titulo, String apellidos, String nombre) throws Exception {
		log.debug("Using method executeObtenerEnlaces");

		List<String> errorParams = new ArrayList<>();
		if (Objects.isNull(titulo)) {
			errorParams.add("titulo");
		}
		if (Objects.isNull(apellidos)) {
			errorParams.add("apellidos");
		}
		if (Objects.isNull(nombre)) {
			errorParams.add("nombre");
		}

		if (!errorParams.isEmpty()) {
			System.out.println("Problemas en los parámetros recibidos. Se procede a detener la ejecución del método");
			return null;
		}

		System.out.println("Iniciando ejecución de obtenerEnlaces para el autor: " + nombre + "_" + apellidos
				+ " con su libro: " + titulo);
		String guion = "_";

		String autor = null;

		String lista = null;

		ListaLibros enlaces = null;

		autor = nombre + guion + apellidos;

		try {
			System.out.println("Llamando a la API para obtener la información del libro indicado");
			lista = RestRepository.tPrecios(titulo, autor,
					"AIzaSyBdNYZeVARrXAFO6ZULBgIsUQEteB1qxXg");
			System.out.println("Solicitud realizada exitosamente");
		} catch (Exception e) {

			log.error(e.getMessage(), e);

		}

		try {
			System.out.println("Llamando a filtrado de la respuesta de la API");
			enlaces = filtradoService.filtrar(lista, titulo, autor);
			if (enlaces.getLibros().get(0).getPrecio().equals("0.00")
					&& enlaces.getLibros().get(0).getEnlace().equals("#")) {
				System.out.println("No se han recibido respuestas válidas");
			} else {
				System.out.println("Número de enlaces válidos recibidos " + enlaces.getLibros().size());
			}

		} catch (Exception e) {

			log.error(e.getMessage(), e);

		}
		System.out.println("Enlaces obtenidos exitosamente");
		return enlaces;
	}

	public LibroAuxiliar mejorPrecio(String titulo, String apellidos, String nombre) throws Exception {
		log.debug("Using method executeMejorPrecio");

		System.out.println("Iniciando ejecución de mejorPrecio para el autor: " + nombre + "_" + apellidos
				+ " con su libro: " + titulo);

		List<String> errorParams = new ArrayList<>();
		if (Objects.isNull(titulo)) {
			errorParams.add("titulo");
		}
		if (Objects.isNull(apellidos)) {
			errorParams.add("apellidos");
		}
		if (Objects.isNull(nombre)) {
			errorParams.add("nombre");
		}

		if (!errorParams.isEmpty()) {
			System.out.println("Problemas en los parámetros recibidos. Se procede a detener la ejecución del método");
			return null;
		}

		String guion = "_";

		String autor = null;

		String lista = null;

		LibroAuxiliar libroMin = null;

		autor = nombre + guion + apellidos;

		try {
			System.out.println("Llamando a la API para obtener los precios del libro solicitado");
			lista = restRepository.mPrecios(titulo, autor, "AIzaSyBdNYZeVARrXAFO6ZULBgIsUQEteB1qxXg");
			System.out.println("LLamada a la API realizada correctamente");

		} catch (Exception e) {

			log.error(e.getMessage(), e);

		}

		try {
			System.out.println(
					"Llamando al método comparacionFiltrado que realizará el filtrado y la comparación de la respuesta de la API");
			libroMin = filtradoService.comparacionFiltrado(autor, titulo, lista);
			if (libroMin.getPrecio().equals("0.00")) {
				System.out.println("No se ha encontrado ningún precio relacionado");
			} else {
				System.out.println("Precio y enlace obtenido exitosamente para el libro deseado");
			}

		} catch (Exception e) {

			log.error(e.getMessage(), e);

		}
		System.out.println("Obtención del mejor precio realizado con éxito");
		return libroMin;
	}
}
