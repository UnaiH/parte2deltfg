package com.becdedalow.ms.resenas.domain.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ListaResenasTest {
    @Test
    public void ListaResenaTest() {
        ListaResenas lista = null;
        assertNull(lista);
        lista = new ListaResenas();
        assertNotNull(lista);
        assertNotNull(lista.getResenas());
        assertFalse(lista.getResenas().size() > 0);
        lista.getResenas().add(new Resena("Titulo", "Autor", "Usuario", "PruebaTexto"));
        assertTrue(lista.getResenas().size() > 0);
        assertEquals(lista.getResenas().get(0).getTitulo(), "Titulo");
        assertEquals(lista.getResenas().get(0).getAutor(), "Autor");
        assertEquals(lista.getResenas().get(0).getNombreUsuario(), "Usuario");
        assertEquals(lista.getResenas().get(0).getTexto(), "PruebaTexto");
    }
}
