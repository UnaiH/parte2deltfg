package com.becdedalow.ms.resenas.domain.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

public class LibroTest {
    @Test
    public void LibroTest() {
        Libro lib1 = new Libro("El señor de los anillos", "J.R.R.Tolkien");
        Libro lib2 = null;
        assertNull(lib2);
        assertNotNull(lib1);
        lib2 = new Libro();
        assertEquals(lib1.getAutor(), "J.R.R.Tolkien");
        assertEquals(lib1.getTitulo(), "El señor de los anillos");
        assertNull(lib2.getAutor());
        assertNull(lib2.getTitulo());
        lib2.setAutor("J.R.R.Tolkien");
        lib2.setTitulo("El señor de los anillos");
        assertEquals(lib2.getAutor(), "J.R.R.Tolkien");
        assertEquals(lib2.getTitulo(), "El señor de los anillos");
    }
}
