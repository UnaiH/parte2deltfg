package com.becdedalow.ms.resenas.domain.mapper;

import com.becdedalow.ms.resenas.domain.entity.ResenaEntity;
import com.becdedalow.ms.resenas.domain.model.Resena;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ResenaEntityMapperTest {
  @Autowired
  ResenaEntityMapper mapper;

  @Test
  public void toApiDomainTest() {
    System.out.println("Inicio de prueba");
    ResenaEntity entity = new ResenaEntity();
    List<ResenaEntity> entityList = Arrays.asList(entity);

    Resena domainClass = mapper.toApiDomain(entity);
    List<Resena> domainClassList = mapper.toApiDomain(entityList);

    Assertions.assertNotNull(domainClass);
    Assertions.assertNotNull(domainClassList);
  }

  @Test
  public void fromApiDomainTest() {
    System.out.println("Inicio de prueba");
    Resena domainClass = new Resena();
    List<Resena> domainClassList = Arrays.asList(domainClass);

    ResenaEntity entity = mapper.fromApiDomain(domainClass);
    List<ResenaEntity> entityList = mapper.fromApiDomain(domainClassList);

    Assertions.assertNotNull(entity);
    Assertions.assertNotNull(entityList);
  }
}
