package com.becdedalow.ms.resenas.service;

import com.becdedalow.ms.resenas.domain.crud.LibroEntityService;
import com.becdedalow.ms.resenas.domain.crud.ResenaEntityService;
import com.becdedalow.ms.resenas.domain.model.Libro;
import com.becdedalow.ms.resenas.domain.model.ListaResenas;
import com.becdedalow.ms.resenas.domain.model.ListaResenasAux;
import com.becdedalow.ms.resenas.domain.model.Resena;
import com.becdedalow.ms.resenas.domain.repository.ObtenerCualquierResenaRepository;

import static org.junit.Assert.assertThrows;

import org.jeasy.random.EasyRandom;
import org.jeasy.random.EasyRandomParameters;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ResenasServiceTest {
        @InjectMocks
        @Spy
        private ResenasService resenasService;

        @Mock
        private LibroEntityService libroEntityService;

        @Mock
        private ObtenerCualquierResenaRepository obtenerCualquierResenaRepository;

        @Mock
        private ResenaEntityService resenaEntityService;

        private EasyRandom generator;

        @BeforeEach
        public void setUp() {
                System.out.println("Inicio de prueba");
                EasyRandomParameters parameters = new EasyRandomParameters();
                parameters.overrideDefaultInitialization(true);
                generator = new EasyRandom();
        }

        @Test
        public void obtenerResenasTest() throws Exception {
                System.out.println("Inicio de prueba");

                Mockito.doReturn(generator.nextObject(ListaResenasAux.class))
                                .when(resenaEntityService)
                                .obtenerResenas(Mockito.nullable(String.class), Mockito.nullable(String.class));

                Assertions.assertNotNull(resenasService.obtenerResenas("string", "string"));
        }

        @Test
        public void obtenerResenasObtenerResenasExceptionTest() throws Exception {
                System.out.println("Inicio de prueba");

                Mockito.doThrow(new Exception())
                                .when(resenaEntityService)
                                .obtenerResenas(Mockito.nullable(String.class), Mockito.nullable(String.class));

                resenasService.obtenerResenas("string", "string");
        }

        @Test
        public void obtenerTodasResenasTest() throws Exception {
                System.out.println("Inicio de prueba");

                Mockito.doReturn(generator.nextObject(ListaResenasAux.class))
                                .when(obtenerCualquierResenaRepository)
                                .executeQuery();

                Assertions.assertNotNull(resenasService.obtenerTodasResenas());
        }

        @Test
        public void obtenerTodasResenasObtenerTodasResenasExceptionTest() throws Exception {
                System.out.println("Inicio de prueba");

                Mockito.doThrow(new Exception()).when(obtenerCualquierResenaRepository).executeQuery();

                resenasService.obtenerTodasResenas();
        }

        @Test
        public void enviarTest() throws Exception {
                System.out.println("Inicio de prueba");

                Mockito.doReturn(generator.nextObject(Libro.class))
                                .when(libroEntityService)
                                .findById(Mockito.nullable(String.class), Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Libro.class))
                                .when(libroEntityService)
                                .create(Mockito.nullable(Libro.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .findById(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .update(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .create(Mockito.nullable(Resena.class));

                resenasService.enviar(generator.nextObject(Resena.class));
        }

        @Test
        public void enviarComprobarLibroExceptionTest() throws Exception {
                System.out.println("Inicio de prueba");

                Mockito.doThrow(new Exception())
                                .when(libroEntityService)
                                .findById(Mockito.nullable(String.class), Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Libro.class))
                                .when(libroEntityService)
                                .create(Mockito.nullable(Libro.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .findById(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .update(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .create(Mockito.nullable(Resena.class));

                assertThrows(Exception.class, () -> {
                        resenasService.enviar(generator.nextObject(Resena.class));
                });
        }

        @Test
        public void enviarCrearLibroExceptionTest() throws Exception {
                System.out.println("Inicio de prueba");

                Mockito.doReturn(generator.nextObject(Libro.class))
                                .when(libroEntityService)
                                .findById(Mockito.nullable(String.class), Mockito.nullable(String.class));

                Mockito.doThrow(new Exception()).when(libroEntityService).create(Mockito.nullable(Libro.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .findById(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .update(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .create(Mockito.nullable(Resena.class));

                resenasService.enviar(generator.nextObject(Resena.class));
        }

        @Test
        public void enviarComprobarResenaExceptionTest() throws Exception {
                System.out.println("Inicio de prueba");

                Mockito.doReturn(generator.nextObject(Libro.class))
                                .when(libroEntityService)
                                .findById(Mockito.nullable(String.class), Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Libro.class))
                                .when(libroEntityService)
                                .create(Mockito.nullable(Libro.class));

                Mockito.doThrow(new Exception())
                                .when(resenaEntityService)
                                .findById(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .update(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .create(Mockito.nullable(Resena.class));

                resenasService.enviar(generator.nextObject(Resena.class));
        }

        @Test
        public void enviarActualizarResenaExceptionTest() throws Exception {
                System.out.println("Inicio de prueba");

                Mockito.doReturn(generator.nextObject(Libro.class))
                                .when(libroEntityService)
                                .findById(Mockito.nullable(String.class), Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Libro.class))
                                .when(libroEntityService)
                                .create(Mockito.nullable(Libro.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .findById(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class));

                Mockito.doThrow(new Exception())
                                .when(resenaEntityService)
                                .update(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .create(Mockito.nullable(Resena.class));

                resenasService.enviar(generator.nextObject(Resena.class));
        }

        @Test
        public void enviarCrearResenaExceptionTest() throws Exception {
                System.out.println("Inicio de prueba");

                Mockito.doReturn(generator.nextObject(Libro.class))
                                .when(libroEntityService)
                                .findById(Mockito.nullable(String.class), Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Libro.class))
                                .when(libroEntityService)
                                .create(Mockito.nullable(Libro.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .findById(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class));

                Mockito.doReturn(generator.nextObject(Resena.class))
                                .when(resenaEntityService)
                                .update(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class));

                Mockito.doThrow(new Exception())
                                .when(resenaEntityService)
                                .create(Mockito.nullable(Resena.class));

                resenasService.enviar(generator.nextObject(Resena.class));
        }

        @Test
        public void eliminarResenaTest() throws Exception {
                System.out.println("Inicio de prueba");

                Mockito.doNothing()
                                .when(resenaEntityService)
                                .remove(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class));

                resenasService.eliminarResena("string", "string", "string");
        }

        @Test
        public void eliminarResenaEliminarExceptionTest() throws Exception {
                System.out.println("Inicio de prueba");

                Mockito.doThrow(new Exception())
                                .when(resenaEntityService)
                                .remove(
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class),
                                                Mockito.nullable(String.class));

                resenasService.eliminarResena("string", "string", "string");
        }
}
