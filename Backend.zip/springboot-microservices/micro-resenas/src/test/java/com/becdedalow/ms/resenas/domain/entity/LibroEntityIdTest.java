package com.becdedalow.ms.resenas.domain.entity;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;

public class LibroEntityIdTest {
    @Test
    public void PruebaLibroId() {
        LibroEntityId libroId = null;
        assertNull(libroId);
        libroId = new LibroEntityId();
        assertNotNull(libroId);
        assertNull(libroId.getAutor());
        assertNull(libroId.getTitulo());
        libroId.setAutor("Anónimo");
        libroId.setTitulo("El cantar del mío Cid");
        assertEquals(libroId.getAutor(), "Anónimo");
        assertEquals(libroId.getTitulo(), "El cantar del mío Cid");
    }
}
