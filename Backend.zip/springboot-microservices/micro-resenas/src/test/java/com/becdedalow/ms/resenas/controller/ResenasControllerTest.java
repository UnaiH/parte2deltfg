package com.becdedalow.ms.resenas.controller;

import com.becdedalow.ms.resenas.domain.model.ListaResenas;
import com.becdedalow.ms.resenas.domain.model.ResAux;
import com.becdedalow.ms.resenas.domain.model.Resena;
import com.becdedalow.ms.resenas.service.ResenasService;

import java.util.Arrays;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@SpringBootTest
public class ResenasControllerTest {
  @Autowired
  private ResenasController resenasController;

  @MockBean
  private ResenasService resenasService;

  @Test
  public void obtenerResenasTest() throws Exception {
    System.out.println("Inicio de prueba");
    ListaResenas mockedResponse = ListaResenas.builder()
        .resenas(
            Arrays.asList(
                Resena.builder()
                    .nombreUsuario("string")
                    .texto("string")
                    .titulo("string")
                    .autor("string")
                    .build()))
        .build();

    Mockito.when(
        resenasService.obtenerResenas(
            Mockito.nullable(String.class), Mockito.nullable(String.class)))
        .thenReturn(mockedResponse);

    ResponseEntity<ListaResenas> response = resenasController.obtenerResenas("string", "string");

    Assertions.assertNotNull(response);
    Assertions.assertTrue(response.hasBody());
    Assertions.assertEquals(response.getBody(), mockedResponse);
  }

  @Test
  public void obtenerResenasExceptionTest() throws Exception {
    System.out.println("Inicio de prueba");
    Mockito.when(
        resenasService.obtenerResenas(
            Mockito.nullable(String.class), Mockito.nullable(String.class)))
        .thenThrow(new Exception());

    ResponseEntity<ListaResenas> response = resenasController.obtenerResenas("string", "string");

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.NOT_FOUND);
  }

  @Test
  public void obtenerResenasNotFoundTest() throws Exception {
    System.out.println("Inicio de prueba");
    ListaResenas mockedResponse = null;

    Mockito.when(
        resenasService.obtenerResenas(
            Mockito.nullable(String.class), Mockito.nullable(String.class)))
        .thenReturn(mockedResponse);

    ResponseEntity<ListaResenas> response = resenasController.obtenerResenas("string", "string");

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.NOT_FOUND);
  }

  @Test
  public void obtenerResenasNullParamsTest() throws Exception {
    System.out.println("Inicio de prueba");
    ListaResenas mockedResponse = ListaResenas.builder()
        .resenas(
            Arrays.asList(
                Resena.builder()
                    .nombreUsuario("string")
                    .texto("string")
                    .titulo("string")
                    .autor("string")
                    .build()))
        .build();

    Mockito.when(
        resenasService.obtenerResenas(
            Mockito.nullable(String.class), Mockito.nullable(String.class)))
        .thenReturn(mockedResponse);

    ResponseEntity<ListaResenas> response = resenasController.obtenerResenas(null, null);

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
  }

  @Test
  public void obtenerTodasResenasTest() throws Exception {
    System.out.println("Inicio de prueba");
    ListaResenas mockedResponse = ListaResenas.builder()
        .resenas(
            Arrays.asList(
                Resena.builder()
                    .nombreUsuario("string")
                    .texto("string")
                    .titulo("string")
                    .autor("string")
                    .build()))
        .build();

    Mockito.when(resenasService.obtenerTodasResenas()).thenReturn(mockedResponse);

    ResponseEntity<ListaResenas> response = resenasController.obtenerTodasResenas();

    Assertions.assertNotNull(response);
    Assertions.assertTrue(response.hasBody());
    Assertions.assertEquals(response.getBody(), mockedResponse);
  }

  @Test
  public void obtenerTodasResenasExceptionTest() throws Exception {
    System.out.println("Inicio de prueba");
    Mockito.when(resenasService.obtenerTodasResenas()).thenThrow(new Exception());

    ResponseEntity<ListaResenas> response = resenasController.obtenerTodasResenas();

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.NOT_FOUND);
  }

  @Test
  public void obtenerTodasResenasNotFoundTest() throws Exception {
    System.out.println("Inicio de prueba");
    ListaResenas mockedResponse = null;

    Mockito.when(resenasService.obtenerTodasResenas()).thenReturn(mockedResponse);

    ResponseEntity<ListaResenas> response = resenasController.obtenerTodasResenas();

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.NOT_FOUND);
  }

  @Test
  public void enviarTest() throws Exception {
    System.out.println("Inicio de prueba");

    Mockito.doNothing().when(resenasService).enviar(Mockito.nullable(Resena.class));

    ResponseEntity<Void> response = resenasController.enviar("string", "string", "string", "string");

    Assertions.assertNotNull(response);
    Assertions.assertFalse(response.hasBody());
  }

  @Test
  public void enviarExceptionTest() throws Exception {
    Mockito.doThrow(new Exception()).when(resenasService).enviar(Mockito.nullable(Resena.class));

    ResponseEntity<Void> response = resenasController.enviar("string", "string", "string", "string");

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.OK);
  }

  @Test
  public void enviarNullParamsTest() throws Exception {

    Mockito.doNothing().when(resenasService).enviar(Mockito.nullable(Resena.class));

    ResponseEntity<Void> response = resenasController.enviar(null, null, null, null);

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
  }

  @Test
  public void eliminarResenaTest() throws Exception {

    Mockito.doNothing()
        .when(resenasService)
        .eliminarResena(
            Mockito.nullable(String.class),
            Mockito.nullable(String.class),
            Mockito.nullable(String.class));

    ResponseEntity<Void> response = resenasController.eliminarResena("string", "string", "string");

    Assertions.assertNotNull(response);
    Assertions.assertFalse(response.hasBody());
  }

  @Test
  public void eliminarResenaExceptionTest() throws Exception {
    Mockito.doThrow(new Exception())
        .when(resenasService)
        .eliminarResena(
            Mockito.nullable(String.class),
            Mockito.nullable(String.class),
            Mockito.nullable(String.class));

    ResponseEntity<Void> response = resenasController.eliminarResena("string", "string", "string");

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.OK);
  }

  @Test
  public void eliminarResenaNullParamsTest() throws Exception {

    Mockito.doNothing()
        .when(resenasService)
        .eliminarResena(
            Mockito.nullable(String.class),
            Mockito.nullable(String.class),
            Mockito.nullable(String.class));

    ResponseEntity<Void> response = resenasController.eliminarResena(null, null, null);

    Assertions.assertNotNull(response);
    Assertions.assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
  }
}
