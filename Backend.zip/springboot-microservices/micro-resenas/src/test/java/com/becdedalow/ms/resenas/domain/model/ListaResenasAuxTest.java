package com.becdedalow.ms.resenas.domain.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ListaResenasAuxTest {
    @Test
    public void ListaResenaTest() {
        ListaResenasAux lista = null;
        assertNull(lista);
        lista = new ListaResenasAux();
        assertNotNull(lista);
        assertNotNull(lista.getResenas());
        assertFalse(lista.getResenas().size() > 0);
        lista.getResenas().add(new ResAux("Usuario", "PruebaTexto", "Titulo", "Autor"));
        assertTrue(lista.getResenas().size() > 0);
        assertEquals(lista.getResenas().get(0).getTit(), "Titulo");
        assertEquals(lista.getResenas().get(0).getAut(), "Autor");
        assertEquals(lista.getResenas().get(0).getUsu(), "Usuario");
        assertEquals(lista.getResenas().get(0).getRes(), "PruebaTexto");
    }
}
