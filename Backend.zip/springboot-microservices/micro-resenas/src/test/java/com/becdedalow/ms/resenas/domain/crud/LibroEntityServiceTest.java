package com.becdedalow.ms.resenas.domain.crud;

import com.becdedalow.ms.resenas.domain.entity.LibroEntity;
import com.becdedalow.ms.resenas.domain.mapper.LibroEntityMapper;
import com.becdedalow.ms.resenas.domain.model.Libro;
import com.becdedalow.ms.resenas.domain.repository.LibroEntityRepository;
import java.util.ArrayList;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class LibroEntityServiceTest {
  @InjectMocks
  private LibroEntityService libroService;
  @Mock
  private LibroEntityRepository repository;
  @Mock
  private LibroEntityMapper mapper;

  @BeforeEach
  public void setUp() {
    Mockito.when(mapper.fromApiDomain(Mockito.any(Libro.class))).thenReturn(new LibroEntity());
    Mockito.when(mapper.fromApiDomain(Mockito.anyList())).thenReturn(new ArrayList<LibroEntity>());
    Mockito.when(mapper.toApiDomain(Mockito.anyList())).thenReturn(new ArrayList<Libro>());
    Mockito.when(mapper.toApiDomain(Mockito.any(LibroEntity.class))).thenReturn(new Libro());
  }

  @Test
  public void comprobarLibroTest() throws Exception {
    System.out.println("Inicio de prueba");
    Libro result = libroService.findById("Dime quien soy", "Julia Navarro");

    Assertions.assertNull(result);
  }

  @Test
  public void libroTest() throws Exception {
    System.out.println("Inicio de prueba");
    Libro result = libroService.create(Libro.builder().titulo("Dime quien soy").autor("Julia Navarro").build());

    Assertions.assertNotNull(result);
  }
}
