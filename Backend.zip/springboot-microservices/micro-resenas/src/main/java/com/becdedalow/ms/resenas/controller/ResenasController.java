package com.becdedalow.ms.resenas.controller;

import com.becdedalow.ms.resenas.domain.model.ListaResenas;
import com.becdedalow.ms.resenas.domain.model.ListaResenasAux;
import com.becdedalow.ms.resenas.domain.model.Resena;
import com.becdedalow.ms.resenas.service.ResenasService;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.aspectj.weaver.ast.And;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequiredArgsConstructor
public class ResenasController {
  private final ResenasService resenasService;

  @GetMapping("/obtenerResenas")
  public ResponseEntity<ListaResenas> obtenerResenas(@RequestParam(name = "titulo", required = true) String titulo,
      @RequestParam(name = "autor", required = true) String autor) {
    log.debug(
        "Start of call to ResenasController - obtenerResenas with parameters: " + "titulo={}" + " - " + "autor={}",
        titulo, autor);

    System.out
        .println("Comenzando proceso para obtener las reseñas del libro con titulo: " + titulo + "y autor: " + autor);
    List<String> errorParams = new ArrayList<>();
    if (Objects.isNull(titulo)) {
      errorParams.add("titulo");
    }
    if (Objects.isNull(autor)) {
      errorParams.add("autor");
    }

    if (!errorParams.isEmpty()) {
      System.out.println("Parámetro recibido de la petición erróneo o vacío");
      return ResponseEntity.badRequest().build();
    }

    ListaResenas response = null;

    try {
      System.out.println(
          "Iniciando llamada al método obtenerResenas para extraer las reseñas de la base de datos del libro con el título: "
              + titulo + "y autor: " + autor);
      response = resenasService.obtenerResenas(titulo, autor);
      System.out.println("Llamada del método obtenerResenas finalizada");
    } catch (Exception e) {
      log.error("Exception: {0}", e);
      return ResponseEntity.badRequest().build();
    }

    log.debug("End of call to ResenasController - obtenerResenas"
        + " with response={}", response);

    if (response == null) {
      return ResponseEntity.notFound().build();
    } else {

      System.out.println("Método para obtener las rteseñas del libro especificado finalizado");
      return ResponseEntity.ok().body(response);
    }
  }

  @GetMapping("/obtenerTodasResenas")
  public ResponseEntity<ListaResenas> obtenerTodasResenas() {
    log.debug("Start of call to ResenasController - obtenerTodasResenas without parameters");

    System.out.println("Comenzando el proceso para obtener todas las reseñas ");

    List<String> errorParams = new ArrayList<>();

    ListaResenas response = null;

    try {
      System.out.println(
          "Iniciando llamada al método obtenerTodasResenas para extraer todas las reseñas de la base de datos");
      response = resenasService.obtenerTodasResenas();
      System.out.println("Finalizada la llamada al método obtenerTodasResenas");
    } catch (Exception e) {
      log.error("Exception: {0}", e);
      return ResponseEntity.badRequest().build();
    }

    log.debug("End of call to ResenasController - obtenerTodasResenas" + " with response={}", response);

    System.out.println("Finalizado el proceso de obtención de todas las reseñas");

    if (response == null) {
      return ResponseEntity.notFound().build();
    } else {
      return ResponseEntity.ok().body(response);
    }
  }

  @GetMapping("/enviar")
  public ResponseEntity<Void> enviar(@RequestParam(name = "autor", required = true) String autor,
      @RequestParam(name = "titulo", required = true) String titulo,
      @RequestParam(name = "usuario", required = true) String usuario,
      @RequestParam(name = "texto", required = true) String texto) {

    log.debug(
        "Start of call to ResenasController - enviar with parameters: " + "usuario={}" + "titulo={}" + " - "
            + "autor={}" + "texto={}",
        usuario, titulo, autor, texto);
    System.out.println("Petición para guardar una nueva reseña recibida");

    List<String> errorParams = new ArrayList<>();
    if (Objects.isNull(autor)) {
      errorParams.add("autor");
    }
    if (Objects.isNull(titulo)) {
      errorParams.add("titulo");
    }
    if (Objects.isNull(usuario)) {
      errorParams.add("usuario");
    }
    if (Objects.isNull(texto)) {
      errorParams.add("texto");
    }

    if (!errorParams.isEmpty()) {
      System.out.println("Parámetro recibido de la petición erróneo o vacío");
      return ResponseEntity.badRequest().build();
    }
    Resena resena = new Resena(titulo, autor, usuario, texto);
    try {
      System.out.println("Iniciando llamada al método enviar para guardar la reseña del libro con título: "
          + resena.getTitulo() + " y autor: " + resena.getAutor() + " del usuario: " + resena.getNombreUsuario());
      resenasService.enviar(resena);
      System.out.println("Llamada del método enviar finalizada");
    } catch (Exception e) {
      log.error("Exception: {0}", e);
      return ResponseEntity.badRequest().build();
    }
    log.debug("End of call to ResenasController - enviar");

    System.out.println("Método enviar del controller de reseñas finalizada");
    return ResponseEntity.ok().build();
  }

  @GetMapping("/eliminarResena")
  public ResponseEntity<Void> eliminarResena(@RequestParam(name = "autor", required = true) String autor,
      @RequestParam(name = "titulo", required = true) String titulo,
      @RequestParam(name = "usuario", required = true) String usuario) {
    log.debug("Start of call to ResenasController - eliminarResena with parameters: " + "autor={}" + " - " + "titulo={}"
        + " - " + "usuario={}", autor, titulo, usuario);

    System.out.println("Petición para eliminar la reseña creada por el usuario: " + usuario + " para el libro: "
        + titulo + " de " + autor);

    List<String> errorParams = new ArrayList<>();
    if (Objects.isNull(autor)) {
      errorParams.add("autor");
    }
    if (Objects.isNull(titulo)) {
      errorParams.add("titulo");
    }
    if (Objects.isNull(usuario)) {
      errorParams.add("usuario");
    }

    if (!errorParams.isEmpty()) {
      System.out.println("Parámetro recibido de la petición erróneo o vacío");
      return ResponseEntity.badRequest().build();
    }

    try {
      System.out.println("Iniciando llamada al método eliminarResena para eliminar la reseña escrito por " + usuario
          + " para el libro " + titulo + " de " + autor);
      resenasService.eliminarResena(autor, titulo, usuario);
      System.out.println("Llamada del método eliminarResena finalizada");
    } catch (Exception e) {
      log.error("Exception: {0}", e);
      return ResponseEntity.badRequest().build();
    }

    log.debug("End of call to ResenasController - eliminarResena");

    return ResponseEntity
        .ok()
        .build();

  }
}
