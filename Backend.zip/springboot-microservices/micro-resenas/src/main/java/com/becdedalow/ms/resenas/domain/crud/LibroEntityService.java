package com.becdedalow.ms.resenas.domain.crud;

import com.becdedalow.ms.resenas.domain.entity.LibroEntity;
import com.becdedalow.ms.resenas.domain.entity.LibroEntityId;
import com.becdedalow.ms.resenas.domain.mapper.LibroEntityMapper;
import com.becdedalow.ms.resenas.domain.model.Libro;
import com.becdedalow.ms.resenas.domain.repository.LibroEntityRepository;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class LibroEntityService {
  @Autowired
  private final LibroEntityRepository repository;

  @Autowired
  private final LibroEntityMapper mapper;

  public Libro findById(String titulo, String autor) throws Exception {
    System.out.println("Iniciando búsqueda del libro en la base de datos");
    LibroEntityId requestId = new LibroEntityId();

    requestId.setTitulo(titulo);
    requestId.setAutor(autor);

    Optional<LibroEntity> response = repository.findById(requestId);

    System.out.println("Finalizada búsqueda en la base de datos");
    System.out.println(response);
    return (response.isPresent()) ? mapper.toApiDomain(response.get()) : null;
  }

  public Libro create(Libro Libro) throws Exception {
    System.out.println("Creando registro nuevo de la base de datos");
    return mapper.toApiDomain(repository.save(mapper.fromApiDomain(Libro)));
  }
}
