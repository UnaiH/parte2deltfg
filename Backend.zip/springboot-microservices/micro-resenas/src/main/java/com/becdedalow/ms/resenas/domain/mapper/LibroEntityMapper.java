package com.becdedalow.ms.resenas.domain.mapper;

import com.becdedalow.ms.resenas.domain.entity.LibroEntity;
import com.becdedalow.ms.resenas.domain.model.Libro;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface LibroEntityMapper {
  @Mapping(target = "titulo", source = "id.titulo")
  @Mapping(target = "autor", source = "id.autor")
  Libro toApiDomain(final LibroEntity source);

  List<Libro> toApiDomain(final List<LibroEntity> source);

  @Mapping(source = "titulo", target = "id.titulo")
  @Mapping(source = "autor", target = "id.autor")
  LibroEntity fromApiDomain(final Libro source);

  List<LibroEntity> fromApiDomain(final List<Libro> source);
}
