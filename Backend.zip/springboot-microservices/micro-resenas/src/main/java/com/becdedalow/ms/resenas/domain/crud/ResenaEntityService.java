package com.becdedalow.ms.resenas.domain.crud;

import com.becdedalow.ms.resenas.domain.entity.ResenaEntity;
import com.becdedalow.ms.resenas.domain.entity.ResenaEntityId;
import com.becdedalow.ms.resenas.domain.mapper.ResenaEntityMapper;
import com.becdedalow.ms.resenas.domain.model.ListaResenas;
import com.becdedalow.ms.resenas.domain.model.ListaResenasAux;
import com.becdedalow.ms.resenas.domain.model.Resena;
import com.becdedalow.ms.resenas.domain.repository.ResenaEntityRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ResenaEntityService {
  @Autowired
  private final ResenaEntityRepository repository;

  @Autowired
  private final ResenaEntityMapper mapper;

  public void remove(String usuario, String libro, String autor) throws Exception {

    System.out.println("Iniciando eliminación del registro correspondiente");
    ResenaEntityId requestId = new ResenaEntityId();
    requestId.setNombreUsuario(usuario);
    requestId.setTitulo(libro);
    requestId.setAutor(autor);

    repository.deleteById(requestId);
  }

  public Resena findById(String titulo, String autor, String usuario) throws Exception {
    System.out.println("Iniciando búsqueda del registro de la reseña en la base de datos");
    ResenaEntityId requestId = new ResenaEntityId();

    requestId.setTitulo(titulo);

    Optional<ResenaEntity> response = repository.findById(requestId);
    System.out.println("Finalizando búsqueda del registro de la reseña en la base de datos");
    return (response.isPresent()) ? mapper.toApiDomain(response.get()) : null;
  }

  public Resena update(String usuario, String titulo, String autor, String texto) throws Exception {
    System.out.println("Actualizando registro de la reseña en la base de datos");
    return mapper.toApiDomain(repository.save(mapper.fromApiDomain(new Resena(titulo, autor, usuario, texto))));
  }

  public Resena create(Resena Resena) throws Exception {
    System.out.println("Creando registro de la reseña en la base de datos");
    return mapper.toApiDomain(repository.save(mapper.fromApiDomain(Resena)));
  }

  public ListaResenas obtenerResenas(String titulo, String autor) throws Exception {
    System.out.println("Obteniendo los registros de las reseñas del libro deseado");
    ResenaEntityId requestId = new ResenaEntityId();
    ListaResenas lista = new ListaResenas();
    lista.setResenas(new ArrayList<>());

    requestId.setTitulo(titulo);
    requestId.setAutor(autor);
    List<ResenaEntityId> iterar = new ArrayList<>();
    iterar.add(requestId);
    System.out.println("Iniciando búsqueda del registro de la reseña en la base de datos");
    System.out.println("ID a buscar: " + requestId.getTitulo() + " y " + requestId.getAutor());
    List<ResenaEntity> response = repository.findAllById(iterar);
    System.out.println(response.size());
    for (ResenaEntity entity : response) {
      Resena resena = mapper.toApiDomain(entity);
      lista.getResenas().add(resena);
    }
    System.out.println("Finalizando búsqueda del registro de la reseña en la base de datos");

    return lista;
  }
}
